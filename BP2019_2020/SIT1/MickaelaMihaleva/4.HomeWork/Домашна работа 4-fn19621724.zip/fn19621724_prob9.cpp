#include<iostream>
using namespace std;
void god();
int main(){
	god();
system("pause");}
	void god(){ 
	int a;
	do{
		cout<<"Vuvedi godina=";
		cin>>a;
		if(a>=0){
	if(a % 4 == 0){
		cout<<"Godinata e visokosna"<<endl;}
		else
		{
         cout<<"Godinata ne e visokosna"<<endl;}
		}}
	
	while(a>=0);}
		
#include <iostream>
using namespace std;

int main()
{
	int number1, number2, number3;
	cin >> number1 >> number2 >> number3;
	int averageValue = (number1 + number2 + number3) / 3;
	cout << averageValue << endl;

	return 0;
}
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	cout << "Rank" << setw(9) << "Gymnast" << setw(19) << "Nation" <<
		setw(10) << "Ribbon" << setw(6) << "Ball" << setw(10) << "Batons"
		<< setw(6) << "Hoop" << setw(9) << "Total" << endl;
	cout << "1" << setw(17) << "Dina Averina" << setw(14) << "Russia" <<
		setw(10) << "21.650" << setw(8) << "22.950" << setw(8) << "23.000" <<
		setw(8) << "23.800" << setw(8) << "91.400" << endl;
	cout << "2" << setw(18) << "Arina Averina" << setw(13) << "Russia" <<
		setw(10) << "20.850" << setw(8) << "23.100" << setw(8) << "24.050" <<
		setw(8) << "23.100" << setw(8) << "91.100" << endl;
	cout << "3" << setw(17) << "Linoy Ashram" << setw(14) << "Israel" <<
		setw(10) << "21.050" << setw(8) << "23.100" << setw(8) << "23.500" <<
		setw(8) << "22.050" << setw(8) << "89.700" << endl;
	cout << "4" << setw(19) << "Boryana Kaleyn" << setw(14) << "Bulgaria" <<
		setw(8) << "19.900" << setw(8) << "22.400" << setw(8) << "22.350" <<
		setw(8) << "21.625" << setw(8) << "86.275" << endl;
	cout << "5" << setw(22) << "Vlada Nikolchenko" << setw(10) << "Ukraine" <<
		setw(9) << "19.450" << setw(8) << "22.250" << setw(8) << "19.500" <<
		setw(8) << "22.950" << setw(8) << "84.150" << endl;

	return 0;
}
#include <iostream>
using namespace std;

int main()
{
	double a, c, y;
	cin >> a >> c;
	y = sqrt(a + 2) - c * 2;
	cout << y;

	return 0;
}
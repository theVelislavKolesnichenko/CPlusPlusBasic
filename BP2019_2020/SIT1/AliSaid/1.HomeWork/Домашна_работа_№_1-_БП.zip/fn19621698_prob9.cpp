#include <iostream>
using namespace std;

int main()
{
	double a, h, S;
	cin >> a >> h;
	S = (a * h) / 2;
	cout << S << endl;

	return 0;
}
#include <iostream>
using namespace std;

int main()
{
	double a, b, S, P;
	cin >> a >> b;
	S = a * b;
	P = 2 * a + 2 * b;
	cout << S << endl << P << endl;

	return 0;
}
#include <iostream>
using namespace std;

int main()
{
	int a, b, c, z;
	cin >> a >> b >> c;
	z = 2 * (a - b) * (a - c);
	cout << z << endl;

	return 0;
}
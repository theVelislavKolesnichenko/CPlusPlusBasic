/*#include <iostream>
#include <stdio.h>
using namespace std;

//void BITOPERATIONS();
// to finish up
int main()
{
	int a = 12, b=13;
	int e = a & b;
	int f = a | b;
	int g = a ^ b;
	int c = a << 5;
	int	 d = b >> 4;
	cout << "Enter two numbers:\n";
	cout << "~a= " << ~a << endl;
	cout << "a & b = " << e << endl;
	cout << "a | b = " << f << endl;
	cout << "a ^ b = " << g << endl;
	cout << "a << 5 = " << c << endl;
	cout << "b >> 4 = " << d << endl;

	//cin >> a >> b;
	//cout << "a | b = " << a | b;
	//cout << "a ^ b = " << a ^ b;
	return 0;
}

/*void BITOPERATIONS()
{
	int a = 12, b = 13;
	cout << "Enter two numbers";
	cin >> a >> b;
	cout << "~a= " << ~a << endl << "~b=" << ~b << endl;
	//cout << "a & b = " << a ^ b;
}*/
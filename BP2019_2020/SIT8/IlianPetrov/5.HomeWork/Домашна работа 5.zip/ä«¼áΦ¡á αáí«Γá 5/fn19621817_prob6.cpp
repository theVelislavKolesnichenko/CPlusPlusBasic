#include <iostream>
using namespace std;
double 3Sum(double a, double b, double c);

int main() {
	double a, b, c;
	do {
		cout << "a= ";
		cin >> a;
		cout << "b= ";
		cin >> b;
		cout << "c= ";
		cin >> c;
		cout << 3Sum(a, b, c) << endl;
	} while ((a != 0 && b != 0 && c!=0);
}
double 3Sum(double a, double b, double c)
{
	double d;
	return d = a + b + c;
	return d;
}
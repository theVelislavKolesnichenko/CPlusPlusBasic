#include <iostream>
using namespace std;

void print();
int main() {
	cout << "Start ?" << endl;

	system("pause");

	print();
	return  0;
}

void print()
{
	cout << "Final !" << endl;
}
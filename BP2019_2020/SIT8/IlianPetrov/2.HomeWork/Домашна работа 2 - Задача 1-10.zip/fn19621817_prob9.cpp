#include <iostream>
#include <math.h>
using namespace std;

struct line {
	double a, b, c;
}line;
float x(float a, float b, float c);

int main() {
	float a, b, c, d, P;
	cout << "line.a= ";
	cin >> line.a;
	cout << "line.b= ";
	cin >> line.b;
	cout << "line.c= ";
	cin >> line.c;

	P = float(a+b+c);
	cout << "P= " << P << endl;
	return 0;
}
float X(float a, float b, float c)
{
	return a + b + c;

}
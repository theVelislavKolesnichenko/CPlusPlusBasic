#include <iostream>
using namespace std;
int main()
{
	double x;
	cout << "x= ";
	cin >> x;

	if (x > 0)
	{
		cout << x << " Is Positive ";
	}
	else
	{
		cout << x << " Is Negative ";
	}

	return 0;
}
#include <iostream>
#include <cstdlib>
using namespace std;
int main() {
	int a;
	cout << "Input a number from 0 to 21: ";
	cin >> a;
	switch (a)
	{
	case 0:
		cout << "Baby" << endl;
		break;
	case 1:
		cout << "Toddler" << endl;
		break;
	case 2:
		cout << "Toddler" << endl;
		break;
	case 3:
		cout << "Preschool" << endl;
		break;
	case 4:
		cout << "Preschool" << endl;
		break;
	case 5:
		cout << "Gradeschooler" << endl;
		break;
	case 6:
		cout << "Gradeschooler" << endl;
		break;
	case 7:
		cout << "Gradeschooler" << endl;
		break;
	case 8:
		cout << "Gradeschooler" << endl;
		break;
	case 9:
		cout << "Gradeschooler" << endl;
		break;
	case 10:
		cout << "Gradeschooler" << endl;
		break;
	case 11:
		cout << "Gradeschooler" << endl;
		break;
	case 12:
		cout << "Gradeschooler" << endl;
		break;
	case 13:
		cout << "Teen" << endl;
		break;
	case 14:
		cout << "Teen" << endl;
		break;
	case 15:
		cout << "Teen" << endl;
		break;
	case 16:
		cout << "Teen" << endl;
		break;
	case 17:
		cout << "Teen" << endl;
		break;
	case 18:
		cout << "Young Adult" << endl;
		break;
	case 19:
		cout << "Young Adult" << endl;
		break;
	case 20:
		cout << "Young Adult" << endl;
		break;
	case 21:
		cout << "Young Adult" << endl;
		break;
	default:
		cout << "I don't know this number " << endl;

	}
	return 0;
}
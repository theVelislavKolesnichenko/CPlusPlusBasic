#include <iostream>
#include <cstdlib>
using namespace std;
int main() {
	int num;
	cout << "Input a number from 1 to 21: ";
	cin >> num;
	switch (num) {
	case 1:
		cout << "Odd" << endl;
		break;
	case 2:
		cout << "Even" << endl;
		break;
	case 3:
		cout << "Odd" << endl;
		break;
	case 4:
		cout << "Even" << endl;
		break;
	case 5:
		cout << "Odd" << endl;
		break;
	case 6:
		cout << "Even" << endl;
		break;
	case 7:
		cout << "Odd" << endl;
		break;
	case 8:
		cout << "Even" << endl;
		break;
	case 9:
		cout << "Odd" << endl;
		break;
	case 10:
		cout << "Even" << endl;
		break;
	case 11:
		cout << "Odd" << endl;
		break;
	case 12:
		cout << "Even" << endl;
		break;
	case 13:
		cout << "Odd" << endl;
		break;
	case 14:
		cout << "Even" << endl;
		break;
	case 15:
		cout << "Odd" << endl;
		break;
	case 16:
		cout << "Even" << endl;
		break;
	case 17:
		cout << "Odd" << endl;
		break;
	case 18:
		cout << "Even" << endl;
		break;
	case 19:
		cout << "Odd" << endl;
		break;
	case 20:
		cout << "Even" << endl;
		break;
	case 21:
		cout << "Odd" << endl;
		break;
	default:
		cout << "I don't know this number " << endl;

	}
	system("pause>nul");
	return 0;
}
#include <iostream>
using namespace std;
int MAX(int y);
int main()
{
	int y;
	cout << "y= ";
	cin >> y;
	cout << MAX(y)<< endl;
	return 0;
}

int MAX(int y)
{
	if (y<1)
	{
		cout<<"Baby Age:";
		return y;
	}
	else if ((y >= 1) && (y <3))
	{
		cout << "Toddler Age:";
		return y;
	}
	else if ((y >= 3) && (y < 5))
	{
		cout << "Preschooler Age:";
		return y;
	}
	else if ((y >= 5) && (y <= 12))
	{
		cout << "Gradeschooler Age:";
		return y;
	}
	else if ((y >= 13) && (y < 18))
	{
		cout << "Teen  Age:";
		return y;
	}
	else if ((y >= 18) && (y < 21))
	{
		cout << "Young Adult   Age:";
		return y;
	}
}
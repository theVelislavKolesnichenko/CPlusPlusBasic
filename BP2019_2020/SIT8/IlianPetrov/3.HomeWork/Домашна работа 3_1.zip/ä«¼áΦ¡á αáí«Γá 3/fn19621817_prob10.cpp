#include <iostream>
using namespace std;
int MAX(int y);
int main()
{
	int y;
	cout << "y= ";
	cin >> y;
	cout << MAX(y) << endl;
	return 0;
}

int MAX(int y)
{
	if (y % 2 == 0)
	{
		cout << "Even Number: ";
		return y;
	}
	else 
	{
		cout << "Odd Number: ";
		return y;
	}
}
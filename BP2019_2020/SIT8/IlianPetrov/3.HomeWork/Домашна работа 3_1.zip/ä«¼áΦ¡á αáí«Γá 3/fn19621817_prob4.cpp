#include <iostream>
using namespace std;
double MAX(double y);
int main()
{
	double y;
	cout << "y= ";
	cin >> y;
	cout << MAX(y) << endl;
	return 0;
}

double MAX(double y)
{
	if (y > 0)
	{
		double x;
		return x = 20 / y;
		return x;
	}
	else if (y == 0)
	{
		cout << "You can't divide by  ";
		return 0;
	}
}
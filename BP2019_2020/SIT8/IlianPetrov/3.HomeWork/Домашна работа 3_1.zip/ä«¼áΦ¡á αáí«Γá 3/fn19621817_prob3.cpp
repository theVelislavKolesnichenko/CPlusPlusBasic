#include <iostream>
using namespace std;
double MAX(double x);
int main()
{
	double x;
	cout << "x= ";
	cin >> x;

	cout << MAX(x) << endl;
	return 0;
}

double MAX(double x, double y)
{
	if (x > 0)
	{
		cout << x << " Is Positive";
		return x;
	}
	else
	{
		cout << x << " Is Negative";
		return x;
	}
}

#include<iostream>
using namespace std;
int c(int a, int b, int c);
int d(int a, int b, int d);
int e(int a, int b, int e);
int f(int a, int f);
int g(int a, int g);
int h(int a, int h);

int main()
{
	int a, b;
	cout << "a= ";
	cin >> a;
	cout << "b= ";
	cin >> b;
	int c, d, e, f, g, h;
	cout << "Value of C for a&b is: " << c << endl;
	cout << "Value of D for a|b is: " << d << endl;
	cout << "Value of E for a^b is: " << e << endl;
	cout << "Value of F for ~a is: " << f << endl;
	cout << "Value of G for a<<5 is: " << g << endl;
	cout << "Value of H for a>>4 is: " << h << endl;

	return 0;
}
int c(int a, int b, int c)
{
	int a, b, c;
	c = a & b;
	return c;
}
int d(int a, int b, int d)
{
	int a, b, d;
	d = a | b;
	return d;
}
int e(int a, int b, int e)
{
	int a, b, e;
	e = a ^ b;
	return e;
}
int f(int a, int f)
{
	int a, f;
	f = ~a;
	return f;
}
int g(int a, int g)
{
	int a, g;
	a << 5;
	return g;
}
int h(int a, int h)
{
	int a, h;
	a >> h;
	return h;
}
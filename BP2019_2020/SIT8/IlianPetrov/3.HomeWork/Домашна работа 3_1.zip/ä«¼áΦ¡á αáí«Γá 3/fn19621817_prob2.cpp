#include <iostream>
using namespace std;
double MAX(double x, double y);
int main()
{
	double x, y;
	cout << "x= ";
	cin >> x;
	cout << "y= ";
	cin >> y;

	cout << "The Bigger Number is: " << MAX(x, y) << endl;
	return 0;
}

double MAX(double x, double y)
{
	if (x > y)
	{
		return x;
	}
	else
	{
		return y;
	}
}

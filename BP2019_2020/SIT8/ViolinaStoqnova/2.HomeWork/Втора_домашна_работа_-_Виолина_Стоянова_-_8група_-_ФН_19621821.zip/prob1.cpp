#include <iostream>
using namespace std;

int main()
{
	cout << "Start?" << endl;

	char next_symbol;
	cin.get(next_symbol);

	cout << "Final!" << endl;

}

#include <iostream>
struct triangle {
	double a, b, c,P;
};
using namespace std;
int main()
{
	double a, b, c, P;
	triangle;
	cout << "a=" << endl;
	cin >> a;
	cout << "b=" << endl;
	cin >> b;
	cout << "c=" << endl;
	cin >> c;
	
	P = a + b + c;
	cout << "P=" << P << endl;

	return 0;

}

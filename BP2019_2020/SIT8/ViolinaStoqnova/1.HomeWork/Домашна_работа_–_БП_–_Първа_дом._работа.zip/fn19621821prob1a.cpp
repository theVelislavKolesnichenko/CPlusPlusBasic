#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	double a, b, c;
	cout << "Choose A=" << endl;
	cin >> a;

	cout << "Choose B=" << endl;
	cin >> b;

	c = a / b;
	cout << "c=" << c << endl;
	return 0;


}

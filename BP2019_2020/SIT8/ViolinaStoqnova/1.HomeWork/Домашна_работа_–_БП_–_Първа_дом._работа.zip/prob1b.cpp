#include <iostream>
using namespace std;
int main()
{
	double B, D;
	float A;

	cout << "Choose A=" << endl;
	cin >> A;

	cout << "Choose B=" << endl;
	cin >> B;

	D = A / B;

	cout << "D=" << D <<  endl;

	return 0; 

}


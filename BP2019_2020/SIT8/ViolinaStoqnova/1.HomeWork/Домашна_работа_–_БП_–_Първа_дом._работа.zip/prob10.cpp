#include <iostream>
using namespace std;
int main()
{
	int P, S;
	int a = 6;
	int b = 10;

	P = (a + b)*2;
	S = a * b;

	cout << "P=" << P << endl;
	cout << "S=" << S << endl;

	return 0;

}
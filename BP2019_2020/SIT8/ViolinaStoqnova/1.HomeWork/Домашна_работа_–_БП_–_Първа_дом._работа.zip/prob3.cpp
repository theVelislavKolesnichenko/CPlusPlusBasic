#include <iostream>
#include <math.h>
using namespace std;
#define SUM(a,b,c) (a+b+c)
int main()
{
	int a = 6;
	int b = 7;
	int c = 5;

	cout << " Units" << a << " Tens" << b << "Hundreds" << c << endl;
	return 0;

}
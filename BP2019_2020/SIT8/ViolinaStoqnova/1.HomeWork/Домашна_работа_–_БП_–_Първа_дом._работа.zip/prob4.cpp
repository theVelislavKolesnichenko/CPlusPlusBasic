#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	cout << "Rank" << setw(10) << "Gymnast" << setw(16) << "Nation" << setw(9)<< "Ribbon" << setw (9) << "Ball" << setw(10)<< "Batons" << setw(9) << "Hoop" << setw(9) << "Total" << endl;
	cout << "1" << setw(18) << "Dina Averina" << setw(11) << "Russia" << setw(9) <<"21.650" << setw(11)<< "22.950" << setw(8)<< "23.000" << setw(11)<< "23.800" << setw(8) << "91.400" << endl;
	cout << "2" << setw(19) << "Arina Averina" << setw(10) << "Russia" << setw(9) << "20.850" << setw(11) << "23.100" << setw(8) << "24.050" << setw(11) << "23.100" << setw(8) << "91.100" << endl;
	cout << "3" << setw(18) << "Linoy Ashram" << setw(11) << "Israel" << setw(9) << "21.050" << setw(11) << "23.100" << setw(8) << "23.500" << setw(11) << "22.050" << setw(8) << "89.700" << endl;
	cout << "4" << setw(20) << "Boryana Kaleyn" << setw(11) << "Bulgaria" << setw(7) << "19.900" << setw(11) << "22.400" << setw(8) << "22.350" << setw(11) << "21.625" << setw(8) << "86.275" << endl;
	cout << "5" << setw(23) << "Vlada Nikolchenko" << setw(7) << "Ukraine" << setw(8) << "19.450" << setw(11) << "22.250" << setw(8) << "19.500" << setw(11) << "22.950" << setw(8) << "84.150" << endl;

	return 0; 

} 


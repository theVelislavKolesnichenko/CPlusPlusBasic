#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	int s;
	int a = 5;
	int ha = 3;

	s = (a * ha) / 2;

	cout << "s=" << s <<endl ;

	return 0;
}
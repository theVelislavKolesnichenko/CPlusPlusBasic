#include <iostream>
using namespace std;
int main()
{
	double x;
	cout << "Choose a random number x=";
	cin >> x;
	{
		if (x > 0)
		{
			cout << " This number is positive";
		}
		else
		{
			cout << " This number is negative";
		}
		
	}
}
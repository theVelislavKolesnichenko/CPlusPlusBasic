#include<iostream>
using namespace std;
int main()
{
	int a;
	cout<<"a= ";
	cin>>a;
	if (a>0)
	{
		cout<<"positive";
	}
	else
	{
	cout<<"negative"<<endl;
	}
	return 0;
}
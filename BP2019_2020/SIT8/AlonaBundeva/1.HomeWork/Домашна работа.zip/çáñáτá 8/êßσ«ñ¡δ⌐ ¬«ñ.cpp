#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int x,y;
	cout<<"Y= ";
	cin>>y;
	 x=(2*y+5)/(14-y/3);
	 cout<<"X= "<<x<<endl;
	 return 0;
}
#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int a,b,c,z;
	cout<<"A= ";
	cin>>a;
	cout<<"B= ";
	cin>>b;
	cout<<"C= ";
	cin>>c;
	 z=2*(a - b) * (a - c);
	 cout<<"Z= "<<z<<endl;
	 return 0;
}
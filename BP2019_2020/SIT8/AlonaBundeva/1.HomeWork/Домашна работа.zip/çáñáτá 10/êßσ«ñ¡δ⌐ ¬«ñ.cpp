#include<iostream>
using namespace std;
int main()
{
	int a, b , s, p;
	cout<<"A= ";
	cin>>a;
	cout<<"B= ";
	cin>>b;
	 s= a * b;
	 cout<<"S= "<<s<<endl;
	 p=(a+b)*2;
	 cout<<"P= "<<p<<endl;
	 return 0;
}
#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int a,c,y;
	cout<<"A= ";
	cin>>a;
	cout<<"C= ";
	cin>>c;
	 y=sqrt(a+2)-c*2;
	 cout<<"Y= "<<y<<endl;
	 return 0;
}
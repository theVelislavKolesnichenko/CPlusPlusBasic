#include<iostream>
using namespace std;
int main()
{
	int a, h, s;
	cout<<"A= ";
	cin>>a;
	cout<<"H= ";
	cin>>h;
	 s= (a * h)/2;
	 cout<<"S= "<<s<<endl;
	 return 0;
}
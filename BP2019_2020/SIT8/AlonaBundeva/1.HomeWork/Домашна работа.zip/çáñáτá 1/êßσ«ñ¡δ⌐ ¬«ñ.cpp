#include<iostream>
#include<math.h>
using namespace std;
int main()
{ 
	int a, b;
double c, d;
cout<<"a= ";
cin>>a;
cout<<"b= ";
cin>>b;
c=a/b;
cout<<"c= "<<c<<endl;
d=float(a)/b;
cout<<"d= "<<d<<endl;
return 0;//
}



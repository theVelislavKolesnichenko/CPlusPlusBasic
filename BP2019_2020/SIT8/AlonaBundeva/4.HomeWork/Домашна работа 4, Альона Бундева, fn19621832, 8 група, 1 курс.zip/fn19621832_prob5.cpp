#include<iostream>
using namespace std;
int main()
{
	int n;
	cout<<"n= "<<n<<endl;
	while (n>0)
	{
	
		n=n-1;
	}
	return 0;
}
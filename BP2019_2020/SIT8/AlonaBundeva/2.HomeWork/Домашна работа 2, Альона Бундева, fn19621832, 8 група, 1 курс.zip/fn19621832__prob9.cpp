#include< iostream>
using namespace std;
int main()
{
	int a, b, c, x;
	cout << "a=";
	cin >> a;
	cout << "b=";
	cin >> b;
	cout << "c=";
	cin >> c;
	x = (a + b + c);
	cout << "x=" << x << endl;
	return 0;
}

#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int x;
	int y;
	if (y < 1)
	{
		x = pow(y, 3) + (pow(y, 4) + 2*y);
		cout << "x=" << x << endl;
		cin >> x;
		return 0;
	}
	if (y > 1)
	{
		x=2*(2*y+5)/(14-y/3);
		cout << "x=" << x << endl;
		cin >> x;
	}
		return 1;
	}


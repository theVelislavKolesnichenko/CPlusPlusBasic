#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int x;
	int y;
	if (y >= 58 && y <= 87)
	{
		x = pow(y, 3)+(pow(y, 4) + 2*y);
			cout << "x=" << x << endl;
		cin >> x;
	}
	else(y < 58) && (y > 87)
	{
		cout << "x=0" << x;
		{
			return 0;
		}
	if (y > 15 && y <= 58)
	{
		x = 2 * (2 * y + 5) / (14 - y / 3);
		cout << "x=" << x << endl;
		cin >> x;
	}
	else (y < 15 && y>58)
	{
		cout << "x=0" << x;
	}
	
	return 0;
}








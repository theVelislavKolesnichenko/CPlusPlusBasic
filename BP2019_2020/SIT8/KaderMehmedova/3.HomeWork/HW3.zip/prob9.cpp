#include<iostream>
#include<math.h>
using namespace std;
void main()
{
	int a; int symbol;
	cout << "\n Vivedete vizrast:";
	cin >> a;
	if (a < 0 && a>21)
		cout << a << "Nevalidna vizrast \n";

	{
		if (a = 0 && a = 1)
			cout << "Baby" << endl;
		cin >> Baby;
	}
	else if (a < 0 && a>1)
}
if (a >= 1 && a < 3)
{
	cout << "Toddler" << endl;
	cin >> Toddler;
}
else if (a < 1 && a>3)
{
	if (a >= 3 && a < 5)
	{
		cout << "Preschool" << endl;
		cin >> Preschool;
	}
	else if (a < 3 && a>5)
	}
	if (a >= 5 && a <= 12)
	{
		cout << "Gradeschooler" << endl;
		cin >> Gradeschooler;
	}
	else if (a < 5 && a>12)
	}
	if (a >= 13 && a < 18)
	{
		cout << "Teen" << endl;
		cin >> Teen;
	}
	else if (a < 13 && a>18)
	}
	if (a >= 18 && a < 21)
	{
		cout << "Young Adult" << endl;
		cin >> Young Adult;
	}
	else if (a < 18 && a > 21)
		}
		{
		cout << "Vizrasta e" << a << endl;
		cin >> "Vizrasta e" >> a >> endl;

	}

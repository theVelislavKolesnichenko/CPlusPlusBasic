#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int x;
	int y;
	if (y >= -5)
	{
		x = pow(y, 3) + (pow(y, 4) + 2 * y);
		cout << "x=" << x << endl;
		cin >> x;
	}
	else if (y < -5)
	{
		cout << "x=0";
		cin >> 0;
	}
	return 0;


if (y>=5)
{
	x = 2 * (2 * y + 5) / (14 - y / 3);
	cout << "x=" << x << endl;
	cin >> x;
}
else if (y < 5)
{
	cout << "x=0";
	cin >> 0;
}
return 0;
}
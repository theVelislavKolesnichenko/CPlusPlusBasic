#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int x;
	int y;

	cout << "y=" << y << endl;
	cin >> y;
	x = 20 / y;                                                         
	
	if (y > 0)
	{
		cout<<"x = (20 / y)"<<endl;
		cout << "x=" <<x<< endl;
		cin >> x;

	}
	else(y==0)
	{
		
		cout << "Nqma delenie!" << endl;

	}
		return 0;
	}
	
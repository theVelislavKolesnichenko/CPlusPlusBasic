#include <iostream>
using namespace std;
int main()
{
	int num;
	cout << "Enter an integer: ";
	cin >> num;
	if (num < 0) cout << "Number is negative.";
	if (num > -1) cout << "Number is non-negative.";
	return 0;
}








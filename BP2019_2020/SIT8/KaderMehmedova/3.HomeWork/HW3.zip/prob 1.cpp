#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int a = 10;
	int b = 25;
	int c;
	int d;

	cout << ~a << endl;
	cout << ~b << endl;
	cout << (a & b) << endl;
	cout <<( a | b) << endl;
	cout << (a ^ b) << endl;
	 c = a << 4;
	 c = b << 4;
	cout << c << endl;
	 d = a >> 5;
	 d = b >> 5;
	cout << d << endl;
	return 0;

}
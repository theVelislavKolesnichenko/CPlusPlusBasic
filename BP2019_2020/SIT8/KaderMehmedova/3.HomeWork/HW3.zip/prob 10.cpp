#include<iostream>
using namespace std;
void main()
{
	int a;
	cout << "Vavedete chislo:";
      cin >> a;
	if (a % 2 == 0)
		cout << "Even!" << endl;
	else
		cout << "Odd!" << endl;
}
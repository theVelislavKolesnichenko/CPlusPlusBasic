#include<iostream>
using namespace std;
int main()
{
	int a ;
	int b;
	int max;
	cout <<"Vivedete cisla:\n";
	cin >> a >> b;
	max = a;
	if (a > max)max = a;
	if (b > max)max = b;
	cout << max << endl;
	return 0;
}
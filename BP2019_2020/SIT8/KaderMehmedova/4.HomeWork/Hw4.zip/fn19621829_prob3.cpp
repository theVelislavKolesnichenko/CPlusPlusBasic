#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int a, int b, int i, int MAX, int MIN;
	
	for (int i = MIN; (a, b); (i>= 1 ),i--;
		{
			if (a % i == 0 && b % i == 0);
			
	for (long long i = MAX(a, b); i <= (long long)a * b; i++) 
		if (i % a == 0 && i % b == 0) 
		{
			return i;
		}
	}
}
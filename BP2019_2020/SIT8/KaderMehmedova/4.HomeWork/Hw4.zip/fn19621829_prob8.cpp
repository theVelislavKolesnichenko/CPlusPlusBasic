#include<iostream>
using namespace std;
void main()
{
	int cislo;
	{
		cout << "Vivedete cislo:\n";
		cin >> cislo;
	}
	if (cislo >= 1000 && cislo >= 9999)
	{
		cout << "four-digit\n";
	}
	 else if (cislo>9999)
	{
		cout << "more four-digit\n";
	}
	 if (cislo <= 1000)
	{
		cout << "less four-digit\n";
	}
	 else if (cislo == 0)
	 {
		 exit(0);
	 }
	 system("pause");
}
 

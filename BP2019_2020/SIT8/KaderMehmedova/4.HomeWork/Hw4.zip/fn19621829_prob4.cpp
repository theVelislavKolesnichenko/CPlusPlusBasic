#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	double a, b, d;
	double D, x1, x2;
	cout << "Vivedete koeficientite:\n";
	cout << "a=";
	cin >> a;
	cout << "b=";
	cin >> b;
	cout << "d=";
	cin >> d;
	cout << "D";
	cin >> D;
	cout << "x1";
	cin >> x1;
	cout << "x2";
	cin >> x2;
	cin >> a >> b >> d>> D>> x1>> x2;
	if (a == 0)
	{
		if (b == 0)
		{
			if (d == 0)
			{
				cout << "Vsqko cislo e reshenie\n";
			}
			else
			{
				cout << "Uravnenieto nqma reshenie\n";
			}
		}
		else
		{
			x1 = -d / b;
			cout << "Reshenie na uravnenieto e  �=" << x1 << endl;
		}
	}
	else
	{
		D = b * b - 4 * a * d;
		if (D >= 0)
		{
			x1 = (-b + sqrt(D)) / (2 * a);
			x2 = (-b - sqrt(D)) / (2 * a);
			cout << "Resheniq na uravneniqta sa �1=" << x1 << " � �2=" << x2 << endl;
		}
		else
		{
			cout << "Uravnenieto nqma reshenie\n";
		}
	}
	return 0;
}
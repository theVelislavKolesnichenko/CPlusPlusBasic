﻿#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int y, a, c;
	cout << "a=";
	cin >> a;
	cout << "c=";
	cin >> c;
	if (c > 0)
	{
		cout<<"y = sqrt(a + 2) - 2 / c"<<endl;
		cout << "y=" << y << endl;
		cin >> y;
	}
	else if (c=0 || c<0 )
	{
		cout <<"Invalid Input!!!\n";
	}
	
	return 0;
}

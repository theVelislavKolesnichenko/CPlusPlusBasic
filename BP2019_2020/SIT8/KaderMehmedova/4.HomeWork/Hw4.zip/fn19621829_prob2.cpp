#include<iostream>
using namespace std;
void main()
{
	int mesec;
	cout << "\n Vivedete nomer na mesec:";
	cin >>mesec;
	if (mesec == 1 || mesec == 2 || mesec == 12)
		cout << "Zima!\n";
	else if (mesec == 3 || mesec == 4 || mesec == 5)
		if (mesec >= 3 && mesec <= 5)
			cout << "Prolet!\n";
		 if (mesec == 6 || mesec == 7 || mesec == 8)
			cout << "Lqto!\n";
		 if (mesec == 9 || mesec == 10 || mesec == 11)
			cout << "Esen!\n";
		else if (mesec = 0 || mesec > 12)
			cout << "Nqma mesec!\n";
}
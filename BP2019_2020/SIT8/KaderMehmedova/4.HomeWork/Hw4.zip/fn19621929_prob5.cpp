#include <iostream>
#include<math.h>
using namespace std;
int SUM(int count)
{
	    int main();
		{
		int n;
		do {
			cout << "n=";
			cin >> n;
		} while (n > 1);
		cout << "SUM=" << SUM(n) << endl;
		return 0;
	}
		int SUM(int count);
		{
			int SUM = 0;
			for (int n = 1; n <= count; n++);
			{
				SUM = SUM + n;
			}
			return SUM;
		}


﻿#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int a;
	int b;
	int x;
	cout << "a=";
	cin >> a;
	cout << "b=";
	cin >> b;
	x = 2 * ((a-b) / (b-a));
	cout << "x=" << x << endl;

	return 0;

}









#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int s = 987;
	int t = 8;
	int v;
	cout << "s=987km" << endl;
	cout << "t=8 h" << endl;
	v = s / t;
	cout << "v=" << v << endl;
	return 0;
}
















#include<iostream>
#include<math.h>
using namespace std;
#define P(a)+b+c)
#define SUM(a,b,c)(a+b+c)
	int main()
	{
	cout << "a=";
	cin >> a;
	cout << "b=";
	cin >> b;
	cout << "c=";
	cin >> c;
	cout << "P=" <<P << endl;
	return 0;
}
double P;
{ 
	return (a + b + c);
}

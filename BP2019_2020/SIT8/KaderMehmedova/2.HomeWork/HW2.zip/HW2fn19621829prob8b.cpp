
#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int s = 987;
	int v = 70; 
	int t;
	cout << "s=987 km" << endl;

	cout << "v=123 km\h" << endl;
	
	
	t = s / v;
	cout << "t=" << t << "h"<<endl;
	return 0;
}
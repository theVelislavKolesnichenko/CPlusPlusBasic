#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int a = 12;
	int b = 30;
	int c = 21;
	int d = 45;
	
	cout <<( a + b + c + d )/ 4 << endl;
	(a + b + c + d) / 4;
	return 0;
}
#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int a=837;
	cout << 837 << endl;
	cout << 837 / 100 << endl;
	cout << 837/ 10 % 10 << endl;
	cout << 837% 10 << endl;
	cout << "Stotici:" << endl;
	cout << "Desetici:" << endl;
	cout << "Edinici:" << endl;
	return 0;
}




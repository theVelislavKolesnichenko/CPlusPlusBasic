#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int a = 4;
	int b = 5;
	float c = 7;
	float d = 9;

	cout << a + b << endl;
	cout << b - a << endl;
	cout << c * c - d << endl;
		cout << d / c + a << endl;
		return 0;
}
#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int a;
	int b;
	int x;
	cout << "a=";
	cin >> a;
	cout << "b=";
	cin >> b;
	x = (a + b) * (a + b) * (a + b) + (a * a + 2 * b * a - 2 * a * b + b * b);
	cout << "x=" << x << endl;
	return 0;
}
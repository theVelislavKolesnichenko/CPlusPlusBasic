#include <iostream>
#include<math.h>
using namespace std;
int main()
{
	double a;
	double b;
	double  s;
	cout << "a=";
	cin >> a;
	cout<<"b =";
	cin >> b;
	s = a * b;
	cout << "s= " << s << "\n";
	
	return 0;
}
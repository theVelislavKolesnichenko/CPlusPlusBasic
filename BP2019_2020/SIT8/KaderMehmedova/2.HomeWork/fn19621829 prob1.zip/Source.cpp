#include<stdio.h>
#include <stdlib.h>
using namespace std;
int main(void)
{
	puts("Start?\n");

	getchar();

	puts("FINAL!\n");

	system("pause");

	return 0;
	
}
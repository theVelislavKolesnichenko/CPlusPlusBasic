#include<iostream>
using namespace std;
void arr_in(int a[], int count);
void print(int a[], int count);
int sum(int a[], int count);
int main() {
	int arr[12];
	cout << "Enter:" << endl;
	arr_in(arr, 12);
	cout << "Print" << endl;
	print(arr, 12);
	cout << "sum()=" << sum(arr, 12);
	system("pause");
	return 0;
}
void arr_in(int a[], int count) {
	for (int i = 0; i < count; i++) {
		cout << "a[" << i << "]=";
		a[i] = (i + 1);
	}
}
void print(int a[], int count) {
	for (int i = 0; i < count; i++) {
		cout << a[i] << "\t";
		if (i == 9) {
			cout << endl;
		}
	}
}
int sum(int a[], int count) {
	int sum = 0;
	for (int i = 0; i < count; i++) {
		sum = sum + a[i];
	}
	return sum;
}
#include<iostream>
using namespace std;
void arr_in(int a[], int count);
int main() {
	int arr[12];
	cout << "Enter:" << endl;
	arr_in(arr, 12);
	cin.get();
	system("pause");
	return 0;
}
void arr_in(int a[], int count) {
	for (int i = 0; i < count; i++) {
		cout << "a[" << i << "]=";
		a[i]=(i+1);
		cout << a[i] << "\n"<<"\t";
		if (i == 4) {
			cout << endl;
		}
		if (i == 9) {
			cout << endl;
		}
	}
}
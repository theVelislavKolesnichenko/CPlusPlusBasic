#include<iostream>
using namespace std;
void arr_in(int a[], int count);
void print(int a[], int count);
int main() {
	int arr[10];
	cout << "Enter:" << endl;
	arr_in(arr, 10);
	cout << "Print" << endl;
	print(arr, 10);
	return 0;
}
void arr_in(int a[], int count) {
	for (int i = 0; i < count; i++) {
		cout << "a[" << i << "]=";
		cin >> a[i];
	}
}
void print(int a[], int count) {
	for (int i = 0; i < count; i++) {
		cout << "a[" << i << "]=" << a[i] << endl;
	}
}
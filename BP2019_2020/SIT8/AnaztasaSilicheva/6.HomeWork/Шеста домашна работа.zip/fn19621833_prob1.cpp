#include<iostream>
using namespace std;

int main() {
	int arr[]= { 5, 5, 9, 7, 6, 10, 55, 788, 3 };
	for (int i = 0; i < 9; i++)
	cout << " " << arr[i];
	cin.get();
	system("pause");
	return 0;
}

#include<iostream>
using namespace std;
int broi(int chislo) {
	int br = 0;
	if (chislo != 0) {
		br++;
		broi(chislo / 10);
	}
	return br;
}

int main()
{
	int a, b, br;
	for (a >= -2147483648 ; b <= 2147483648; a++)
	{
		cout << "Wywedete chislo: ";
		cin >> b;
		cout << broi() << endl;
	}
	cout << "Broi e: " << broi << "\n";
	system("pause");
	return 0;
}
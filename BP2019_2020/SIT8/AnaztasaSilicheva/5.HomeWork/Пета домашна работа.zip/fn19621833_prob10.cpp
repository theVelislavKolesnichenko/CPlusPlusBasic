#include<iostream>
using namespace std;
void sum(int a, int b) {
	int sum = 0;
	cout<<(b>a);
	cout << "a";
	cin >> a;
	cout << "b";
	cin >> b;
	sum = a + b;
	a = sum;
}
void pow(int a, int b, int sum) {
	sum = a * b;
}
int main() {
	cout << sum() << endl;
	return 0;
}
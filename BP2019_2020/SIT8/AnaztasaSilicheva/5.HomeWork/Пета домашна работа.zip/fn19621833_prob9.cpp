#include<iostream>
using namespace std;
void add();
void mul_pow(int x, int y)
{
	cout<<(x > y);
	int mul = x * y;
	x=mul;
}
int main() {
	int x,y;
	cout << x << endl;
	cout<< mul_pow(x,y) << endl;
	return 0;
}
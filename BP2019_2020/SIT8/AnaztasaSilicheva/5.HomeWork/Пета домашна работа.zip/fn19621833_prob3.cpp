#include<iostream>
#include<math.h>
using namespace std;
int main() {
	int a,y;
	long x;
	for (a = 0; a >= -100 && a <= 100; a++) {
		cout << "Vvedite chislo:";
		cin >> x;
		do {
			y = sqrt(pow(x, 2) + 1);
		} while (x < 0);
		do {
			y = (x + 10) / (x - 20);
		} while (x >= 0);
	}
	system("pause");
	return 0;
}
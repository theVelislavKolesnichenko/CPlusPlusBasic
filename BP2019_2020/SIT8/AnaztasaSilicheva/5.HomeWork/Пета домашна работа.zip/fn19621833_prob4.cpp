#include<iostream>
#include<math.h>
using namespace std;
int main() {
	int a, y;
	long x;
	for (a = 0; a >= -100 || a <= 100; a++) {
		cout << "Vvedite chislo:";
		cin >> x;
		do {
			y = (pow(x, 3) + 1);
		} while (x <= 0);
		do {
			y = sqrt(x-4);
		} while (x >0);
	}
	system("pause");
	return 0;
}
#include<iostream>
using namespace std;
void add();
int main() {
	int a;
	cout << "a=";
	cin >> a;
	cout << a << endl;
	cout << &a << endl;
	return 0;
}
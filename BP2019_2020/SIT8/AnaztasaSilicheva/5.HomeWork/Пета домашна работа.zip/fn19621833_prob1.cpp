#include<iostream>
using namespace std;
int suma(int n)
{
	int suma = 0;
	while (n != 0)
	{
		suma += n;
		n--;
	}
	return suma;
}
int proizv(int p)
{
	int proizv = 1;
	while (p != 0)
	{
		proizv *= p;
		p--;
	}
	return proizv;
}
double S(int n)
{
	double s = double(suma(n)) / double(proizv(n));
	return s;
}

int main(int argc, char* argv[]) {
	int a;
	cout << "a=";
	cin >> a;
	cout << "Sumata na chislata do a (vkl.) e: " << suma(a) << endl;
	cout << "Proizvedenieto na chislata ot 1 do a (vkl.) e: " << proizv(a) << endl;
	cout << "Chastnoto na gornite suma i proizvedenie e: " <<  S(a) << endl;
	system("pause");
	return 0;
}
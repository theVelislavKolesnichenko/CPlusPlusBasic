#include<iostream>
using namespace std;
int AVG();
int main() {
	long b;
	int sum = 0;
	for (int a=0; a <=10 ; a++) {
		cout << "b=";
		cin >> b;
		sum +=b--;
	}

	cout << AVG() << endl;
}
int AVG() {
	int sum = 0; int br = 0;
	for (int i = 0; i <= 10; i++) {
		sum = sum + i;
		br++;
	}
	return sum/br;
}
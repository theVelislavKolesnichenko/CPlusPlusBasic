#include<iostream>
using namespace std;
int sum(int, int, int);
int main() {
	int a, b, c;
	
	cout << "a=";
	cin >> a;
	cout << "b=";
	cin >> b;
	cout << "c=";
	cin >> c;
	if (a, b, c != 0) { cout << sum(a,b,c) << endl; }
	system("pause");
	return 0;
}
int sum(int a, int b, int c) {
	int sum = 0;
	sum = a + b + c;
	return sum;
}
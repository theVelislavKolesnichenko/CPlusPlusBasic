#include<iostream>
using namespace std;
int main() {
	int i,k;
	cout << "k=";
	cin >> k;
	for (i = 1; i < 10.1; i++) {
		cout << i << endl;
	}
if (i == k) {
		cout << "True" << endl;
	}
	else
	{
		cout << "False" << endl;
	}
	system("pause");
	return 0;
}
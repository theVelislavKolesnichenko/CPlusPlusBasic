#include <iostream>
#include <iomanip>
using namespace std;
int show1(int a, int b);
int show2(int a, int b);
int main()
{
	int a;
	//a=time
	cout << "Enter 'Time' (h)!" << endl;
	cout << "Time=";
	cin >> a;
	int b;
	//b=speed
	cout << "Enter 'speed' (km)!" << endl;
	cout << "Speed=";
	cin >> b;
	int x;
	x = show1(a, b);
	x = show2(a, b);
	system("pause");
	return 0;
}

int show1(int a, int b)
{
	int x;
	x = (987 / a);
	cout << "If the time is" << setw(3) << a << setw(6) << "hours" << setw(14) << "the speed is " << x << setw(6) << "km/h." << endl;
	return x;
}

int show2(int a, int b)
{
	int x;
	x = (987 / b);
	cout << "If the speed is" << setw(4) << b << setw(17) << "km/h the time is" << setw(2) << x << setw(6) << "hours" << endl;
	return x;
}

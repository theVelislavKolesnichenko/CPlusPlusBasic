#include<iostream>
using namespace std;
int chislo1(int a, int b, int c);
int chislo2(int a, int b, int c);
int chislo3(int a, int b, int c);
int main()
{
	int a;
	int b;
	int c;
    int x;
	int y;
	int z;

	a = 8;
	b = 3;
	c = 7;
	x = chislo1(a, b, c);
	y = chislo2(b, a, c);
	z = chislo3(c, b, c);
	system("pause");
	return 0;
}
int chislo1(int a, int b,int c) {
	int x;
	x = a;
	cout << x << endl;
	return x;
}
int chislo2(int a, int b, int c)
{
	int y;
	y = b;
	cout << y << endl;
	return y;
}
int chislo3(int a, int b, int c)
{
	int z;
	z = c;
	cout << z << endl;
	return z;
}


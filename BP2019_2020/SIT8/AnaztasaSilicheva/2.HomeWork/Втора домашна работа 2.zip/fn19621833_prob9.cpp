#include< iostream>
using namespace std;
int blab(int a, int b, int c);
int main()
{
	int a;
	int b;
	int c;
	int x;
	cout << "Enter a, b and c" << endl;
	cout << "a=";
	cin >> a;
	cout << "b=";
	cin >> b;
	cout << "c=";
	cin >> c;
	x = blab(a, b, c);
	system("pause");
	return 0;
}
int blab(int a, int b, int c)
{
	int x;
	x = (a + b + c);
	cout << "x=(a + b + c)=" << x << endl;
	return x;
}
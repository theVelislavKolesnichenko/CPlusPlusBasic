#include<iostream>
using namespace std;
int show(int a, int b);
int main()
{
	int a;
	int b;
	int x;
	cout << "Enter a!" << endl;
	cout << "a=";
	cin >> a;
	cout << "Enter b!" << endl;
	cout << "b=";
	cin >> b;
	x = show(a, b);
	cout << "x=" << x << endl;
	system("pause");
	return 0;
}

int show(int a, int b)
{
	int x;
	x = 2 * ((a - b) / (b - a));
	return x;
}

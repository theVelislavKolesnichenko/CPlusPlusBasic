#include<iostream>
#include<math.h>
using namespace std;

int math(int, int, int);

int main()
{
	setlocale(0, "");
	int x;
	int a = 9;
	int b = 8;
	x = pow(a + b, 3) + pow(a, 2) + 2 * b * a - 2 * b * a + pow(b, 2);
	cout << "x=" << x << endl;
	system("pause");
	return 0;
}
int math(int x, int a, int b)
{
	return 0;
}
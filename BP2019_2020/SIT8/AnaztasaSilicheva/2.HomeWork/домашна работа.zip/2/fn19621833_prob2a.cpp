#include <iostream>
using namespace std;

int plus(int, int);

int main()
{
	setlocale(0, "");

	int b = 10;
	int c = 9;
	cout <<b+c << endl;

	system("pause");
	return 0;
}
int plus(int a, int b)
{
	return a + b;
}
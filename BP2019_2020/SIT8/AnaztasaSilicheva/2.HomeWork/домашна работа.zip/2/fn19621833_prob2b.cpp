#include <iostream>
using namespace std;

int pow(char, char);

int main()
{
	setlocale(0, "");

	char b = 8.2;
	char c = 5.2;
	cout << b * c << endl;

	system("pause");
	return 0;
}
int pow(char a, char b)
{
	return a * b;
}
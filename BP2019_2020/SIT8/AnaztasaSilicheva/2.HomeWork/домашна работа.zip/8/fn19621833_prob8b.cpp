#include<iostream>
using namespace std;

int div(int, int, int);

; int main()
{
	setlocale(0, "");

	int t;
	int s = 987;
	int v;
	cout << "Vviditte t=";
	cin >> t;
	v=s/t;
	cout << "v=" << v << endl;
	system("pause");
	return 0;
}
int div(int t, int s, int v) {
	return 0;
}
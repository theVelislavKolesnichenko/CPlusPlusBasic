#include<iostream>
using namespace std;

int pow(int, int, int);

; int main()
{
	setlocale(0, "");

	int t;
	int s = 987;
	int v;
	cout << "Vviditte v=";
	cin>>v;
	t = s * v;
	cout << "t=" << t << endl;
	system("pause");
	return 0;
}
int pow(int t, int s, int v) {
	return 0;
}
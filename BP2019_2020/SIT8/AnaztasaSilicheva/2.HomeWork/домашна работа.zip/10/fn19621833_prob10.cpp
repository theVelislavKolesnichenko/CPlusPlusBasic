#include<iostream>
using namespace std;

int pow(int, int, int);
int main()
{
	setlocale(0, "");

	int s;
	int a, b;
	cout << "Vvidite a=";
	cin >> a;
	b = 9;
	s = a * b;
	cout << "s=" << s << endl;

	system("pause");
	return 0;
}
int pow(int s, int a, int b) {
	return a*b;
}
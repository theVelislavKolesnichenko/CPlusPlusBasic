#include<iostream>
using namespace std;

int pow(int, int);
int main()
{
	setlocale(0, "");

	int p;
	int a;
	cout << "Vvidite a=";
	cin >> a;
	p = 3 * a;
	cout << "p=" << p << endl;

	system("pause");
	return 0;
}
int pow(int p, int a) {
	return 0;
}
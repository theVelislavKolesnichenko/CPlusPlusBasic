#include<iostream>
using namespace std;

int math(int, int);
int main()
{
	setlocale(0, "");

	int x;
	int y;
	cout << "Vvidite y=";
	cin >> y;
	x = 2 * (2 * y + 5) / (14 - y * 3);
	cout << "x=" << x << endl;

	system("pause");
	return 0;
}
int math(int x, int y) {
	return 0;
}
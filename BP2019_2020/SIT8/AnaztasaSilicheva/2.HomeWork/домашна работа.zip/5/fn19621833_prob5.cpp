#include<iostream>
using namespace std;

int math(int, int, int);
int main()
{
	setlocale(0, "");

	int x;
	int a, b;
	cout << "Vvidite a=";
	cin >> a;
	b = 5;
	x = 2 * ((a - b) / (b - a));
	cout << "x=" << x << endl;

	system("pause");
	return 0;
}
int math(int x, int a, int b) {
	return 0;
}
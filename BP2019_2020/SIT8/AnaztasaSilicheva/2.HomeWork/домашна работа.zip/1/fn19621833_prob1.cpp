#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	cout << "Start?";
	getchar();
	cout << "Final!";
	getchar();
	return 0;
}
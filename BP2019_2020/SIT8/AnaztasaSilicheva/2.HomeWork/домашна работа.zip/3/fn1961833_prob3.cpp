#include<iostream>
using namespace std;

int div(int argc, int argb, int arga, int argd);

int main()
{
	setlocale(0,"");

	int c = 5;
	int b = 6;
	int a = 9;
	int d = 1;

	cout << (c + b + a + d) / 4 << endl;
	system("pause");
	return 0;
}
int div(int argc, int argb, int arga, int argd)
{
	return argc + argb + arga + argd / 4;
}
#include<iostream>
using namespace std;
int main() {
	for (int i = 0; i < 2; i++) {
		for (int k = 5; k - i > 0; k--) {
			cout << "%";
		}
		cout << endl;
	}
	for (int i = 0; i < 3; i++) {
		for (int k = 3; k - i > 0; k--){
		cout << "%";
}
	}
	cout << endl;

	system("pause");
	return 0;
}
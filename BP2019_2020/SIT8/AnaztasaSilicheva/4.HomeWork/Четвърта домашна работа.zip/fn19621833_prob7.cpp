#include<iostream>
using namespace std;
int sum1(int count);
int sum(int count);
int main() {
	int n;
	do {
		cout << "n=";
		cin >> n;
	} while (n <0 &&n>0 );
	cout << "sum = "<< sum(n) << endl;
	cout << "sum1=" << sum1(n) << endl;
	system("pause");
	return 0;
}
int sum(int count) {
	int sum = 0;
	while (count < 0);
	{
		sum = sum + count;
		count--;
	}
	return sum;
}
int sum1(int count) {
	int sum = 0;
	while (count > 0);
	{
		sum = sum + count;
			count ++;
	}
	return sum;
}
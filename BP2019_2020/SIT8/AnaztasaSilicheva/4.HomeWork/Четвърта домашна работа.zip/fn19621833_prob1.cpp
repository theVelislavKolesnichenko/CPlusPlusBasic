#include<math.h>
#include<iostream>
#include<iomanip>
using namespace std;
int main() {
	int y, a, c;
	cout << "a=";
	cin >> a;
	cout << "c=";
	cin >> a;
	do {
		y = sqrt(a + 2) - 2 / c;
	} while (a>0, c!=0);
	if (a < 0|| c == 0) {
		cout << "Invalid Input" << endl;
	}
	return 0;
}
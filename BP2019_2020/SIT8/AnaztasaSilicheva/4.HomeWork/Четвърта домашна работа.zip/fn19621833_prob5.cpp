#include<iostream>
using namespace std;
int main() {
	int n;
	cout << "n=";
	cin >> n;
	while (n > 0) {
		cout << "Number:" << n << endl;
		n = n - 1;
	}
	system("pause");
	return 0;
}
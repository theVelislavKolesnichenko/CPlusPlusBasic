﻿#include<iostream>
#include<math.h>

using namespace std;
int main() {
	int x, sum;
	cout << "Enter x:";
	cin >> x;
	for (int i = 1; i <= 20; i++) {
		sum += (pow(x, i) + 1) / (2 * i + 1);
	}
	cout << sum;
	system("pause");
	return 0;
}




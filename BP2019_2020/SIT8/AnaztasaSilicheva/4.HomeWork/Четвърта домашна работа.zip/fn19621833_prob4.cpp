#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	double a, b, c, d, x1, x2, x;
	cout << "a=";
	cin >> a;
	cout << "b=";
	cin >> b;
	cout << "d=";
	cin >> d;
	c = pow(a, x) + 2 * b * x + d;
	if (d > 0)
	{
		x1 = (-b + sqrt(d)) / (2 * a);
		x2 = (-b - sqrt(d)) / (2 * a);
		cout << "x1=" << x1 << "\n";
		cout << "x2=" << x2 << "\n";
	}
	if (d == 0)
	{
		x = -b / 2 * a;
		cout << "X=" << x << "\n";
	}
	if (d < 0)
	{
		cout << "Uravnenieto nqma reshenie" << "\n";
	}
	system("pause");
	return 0;
}
#include <cstdlib>
#include <iostream>

using namespace std;

int main()
{
	int y;
	cout << "Vyvedete cifrata na godinata:" << endl;
	cin >> y;
	if ((y % 4 == 0) && (y % 100 != 0))
		cout << "Godinata e visokosna!" << endl;
	else
		cout << "Godinata ne e visokosna!" << endl;

	system("PAUSE");
	return EXIT_SUCCESS;
}
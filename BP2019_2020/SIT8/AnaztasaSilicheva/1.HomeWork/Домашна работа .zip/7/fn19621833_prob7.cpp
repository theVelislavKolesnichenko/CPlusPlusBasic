#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int y, a, c;
	cout << "Vvedite a=";
	cin >> a;
	cout << "Vvedite c=";
	cin >> c;
	y = sqrt(a + 2) - c * 2;
	cout << "y=" << y << endl;
	return 0;

}
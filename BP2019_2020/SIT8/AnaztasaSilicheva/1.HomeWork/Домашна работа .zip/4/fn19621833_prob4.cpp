#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	cout << "Rank" << setw(22) << left << " Gymnast"
		<< setw(8) << "Nation"
		<< setw(10) << "Ribbon"
		<< setw(12) << "Ball"
		<< setw(7) << " Batons"
		<< setw(9) << " Hoop"
		<< setw(22) << "Total"
		<< endl;
	cout << "1" << setw(22) << left << " Dina Averina"
		<< setw(8) << "Russia"
		<< setw(10) << "21.650"
		<< setw(12) << "22.950"
		<< setw(7) << " 23.000"
		<< setw(9) << " 23.800"
		<< setw(22) << "91.400"
		<< endl;
	cout << "2" << setw(22) << left << " Arina Averina"
		<< setw(8) << "Russia"
		<< setw(10) << "20.850"
		<< setw(12) << "23.100"
		<< setw(7) << " 24.050"
		<< setw(9) << " 23.100"
		<< setw(22) << "91.100 "
		<< endl;
	cout<<"3"<<setw(22)<<left<<" Linoy Ashram"
		<< setw(8) << "Israel"
		<< setw(10) << "21.050"
		<< setw(12) << " 23.100"
		<< setw(7) << " 23.500"
		<< setw(9) << " 22.050"
		<< setw(22) << "89.700"
		<< endl;
	cout<<"4"<<left<<" Boryana Kaleyn"
		<< setw(8) << "Bulgaria"
		<< setw(10) << "19.900"
		<< setw(12) << "22.400"
		<< setw(7) << " 22.350"
		<< setw(9) << " 21.625"
		<< setw(22) << "86.275"
		<< endl;
	cout<<"5"<<left<<" Vlada Nikolchenko"
		<< setw(8) << " Ukraine"
		<< setw(10) << " 19.450"
		<< setw(12) << " 22.250"
		<< setw(7) << " 19.500"
		<< setw(9) << " 22.950"
		<< setw(22) << " 84.150"
		<< endl;
	return 0;
}
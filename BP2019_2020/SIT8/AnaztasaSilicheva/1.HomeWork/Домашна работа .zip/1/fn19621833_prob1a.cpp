#include<iostream>
using namespace std;
int main() 
{
	int a, b;
	float c;
	cout << "Vvedite a=";
	cin >> a;
	cout << "Vvedite b=";
	cin >> b;
	c = a / b;
	cout << "c=" << c << endl;
	return 0;
}
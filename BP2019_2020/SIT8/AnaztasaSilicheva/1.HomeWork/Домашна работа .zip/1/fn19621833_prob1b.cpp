#include<iostream>
using namespace std;
int main()
{
	int b, d;
	float a;
	cout << "Vvidite b=";
	cin >> b;
	cout << "Vvidite a=";
	cin >> a;
	d = (a / b);
	cout << "d=" << d << endl;
	return 0;
}
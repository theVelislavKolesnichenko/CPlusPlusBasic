#include<iostream>
using namespace std;
int main()
{
	int s, p, a, b;
	cout << "Vvedite a=";
	cin >> a;
	cout << "Vvedite b=";
	cin >> b;
	s = a * b;
	p = 2 * (a + b);
	cout << "s=" << s << endl;
	cout << "p=" << p << endl;
	return 0;
}
#include<iostream>
using namespace std;
int main()
{
	int z, a, b, c;
	cout << "Vvedite a=";
	cin >> a;
	cout << "Vvedite b=";
	cin >> b;
	cout << "Vvedite c=";
	cin >> c;
	z = 2 * (a - b) * (a - c);
	cout << "z=" << z << endl;
	return 0;
}
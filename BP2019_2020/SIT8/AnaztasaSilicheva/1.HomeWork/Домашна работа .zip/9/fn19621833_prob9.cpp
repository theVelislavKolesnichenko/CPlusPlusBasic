#include<iostream>
using namespace std;
int main()
{
	int s, a, h;
	cout << "Vvidite a=";
	cin >> a;
	cout << "Vvidite h=";
	cin >> h;
	s = (a * h) / 2;
	cout << "s=" << s << endl;
	return 0;
}
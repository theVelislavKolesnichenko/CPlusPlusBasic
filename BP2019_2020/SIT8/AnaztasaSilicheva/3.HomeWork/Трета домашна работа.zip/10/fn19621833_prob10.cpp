#include<iostream>
using namespace std;

int main()
{
	int x;
	cout << "Vvidite x=";
	cin >> x;
	if (x / 2) {
		cout << "Even";
	}
	else {
		cout << "Odd";
	}
	return 0;
}
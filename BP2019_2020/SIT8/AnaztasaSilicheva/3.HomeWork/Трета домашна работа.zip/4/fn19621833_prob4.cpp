#include<iostream>
using namespace std;
int main() {
	int x, y;
	cout << "Vvidite y=";
	cin >> y;
	x = 20 / y;
	if (y = 0) {
		cout << "There is no decisions" << endl;
	}
	else {
		x = 20 / y;
	}
	cout << x << y << endl;
	system("pause");
	return 0;
}
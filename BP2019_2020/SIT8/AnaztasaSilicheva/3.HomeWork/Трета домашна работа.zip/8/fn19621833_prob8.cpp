#include<iostream>
using namespace std;
int main()
{
	char a, z,o;
	cout << "Wywedete nachalen simwol: "; cin >> a;
		cout << "Wywedete kraen simwol: "; cin >> z;
		for (o = a; o <= z; o++) { cout << o; } 
		cout << endl;
		for (char a = 1; a <= 26; a++) { cout << a; }
		cout << endl;
		system("pause");
		return 0;
}
#include<iostream>

using namespace std;
int main()
{
	int a;
	cout << "Vvidite a=";
	cin >> a;
	if (a > 0)
	{
		cout << "positive" << endl;
	}
	if (a < 0) {
		cout << "negative" << endl;
	}
	return 0;
}

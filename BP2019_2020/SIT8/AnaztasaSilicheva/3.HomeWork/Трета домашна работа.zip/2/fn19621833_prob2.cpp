#include<iostream>
using namespace std;
int main()
{
	int a, b;
	cout << "Vvidite a=";
	cin >> a;
	cout << "Vvidite b=";
	cin >> b;
	if (a > b) {
		cout << "a" << endl;
	}
	if (b > a) {
		cout << "b" << endl;
	}
	cout << a << b << endl;
	system("pause");
	return 0;
}
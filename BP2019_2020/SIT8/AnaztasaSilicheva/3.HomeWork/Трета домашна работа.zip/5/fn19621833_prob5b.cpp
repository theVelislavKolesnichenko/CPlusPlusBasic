#include<math.h>
#include<iostream>
using namespace std;
int main()
{
	int x, y;
	cout << "Vvidite y=";
	cin >> y;
	x = 2 * (2 * y + 5) / (14 - y / 3);
	if (y > 1) {
		x = 2 * (2 * y + 5) / (14 - y / 3);
	}
	cout << x << y << endl;
	system("pause");
	return 0;
}
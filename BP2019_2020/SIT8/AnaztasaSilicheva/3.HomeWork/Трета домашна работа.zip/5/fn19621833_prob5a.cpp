#include<math.h>
#include<iostream>
using namespace std;
int main()
{
	int x, y;
	cout << "Vvidite y=";
	cin >> y;
	x = pow(y, 3) + (pow(y, 4) + 2 * y);
	if (y < 1) {
		x = pow(y, 3) + (pow(y, 4) + 2 * y);
	}
	cout << x << y << endl;
	system("pause");
	return 0;
}
#include<iostream>
using namespace std;
int main() {
	int a;
	cout << "Vvedite age a =";
	cin >> a;
	if (a > 0 & a < 1) {
		cout << "Baby"<<endl;
	}
	if (a >= 1 & a < 3) {
		cout << "Toddler" << endl;
	}
	if (a >= 3 & a < 5) {
		cout << "Preschool" << endl;
	}
	if (a >= 5 & a <= 12) {
		cout << "Gradeschooler" << endl;
	}
	if (a >= 13 & a < 18) {
		cout << "Teen" << endl;
	}
	if (a >= 18 & a < 21) {
		cout << "Young Adult" << endl;
	}
	return 0;
}
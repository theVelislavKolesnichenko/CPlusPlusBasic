#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int a, b;
	cout << "Vvidite a=";
	cin >> a;
	cout << "Vvedite b=";
	cin >> b;
	cout << (~a) << endl;
	cout <<( a && b) << endl;
	cout << (a || b) << endl;
	cout <<( a ^ b )<< endl;
	cout.setf(ios::left);
	cout << setw(5) << a << setw(5) << b << endl;
	cout.setf(ios::right);
	cout << setw(4) << a << setw(4) << b << endl;
	system("pause");
	return 0;
}

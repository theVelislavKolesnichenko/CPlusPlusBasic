#include <iostream>
using namespace std;
int show(int a, int b, int c, int d);

int main()
{
	int a;
	int b;
	int c;
	int d;
	int x;
	cout << "Enter a!" << endl;
	cout << "a=";
	cin >> a;
	cout << "Enter b!" << endl;
	cout << "b=";
	cin >> b;
	cout << "Enter c!" << endl;
	cout << "c=";
	cin >> c;
	cout << "Enter d!" << endl;
	cout << "d=";
	cin >> d;
	x = show(a, b, c, d);

	cout << x << endl;

	return 0;
}

int show(int a, int b, int c, int d)
{
	int x;
	cout << "X=(a + b + c + d)/4 =";
	x = (a + b + c + d) / 4;

	return x;
}
#include <iostream>
using namespace std;
int show (int a, int b);
int show1(int a, int b);
int show2(int a, int b);
int show3(int a, int b);
int main()
{
	int a;
	int b;
	int x;
	cout << "Enter a=";
	cin >> a;
	cout << "Enter b=";
	cin >> b;
	x = show(a, b);
	cout << "x1=" << x << endl;
	x = show1(a, b);
	cout << "x2=" << x << endl;
	x = show2(a, b);
	cout << "x2=" << x << endl;
	x = show3(a, b);
	cout << "x4=" << x << endl;
	return 0;
}
int show(int a, int b)
{
	int x;
	return x=(a + b);
}
int show1(int a, int b)
{
	int x;
	return x = (a - b);
}
int show2(int a, int b)
{
	int x;
	return x = (a * b);
}
int show3(int a, int b)
{
	int x;
	return x = (a / b);
}
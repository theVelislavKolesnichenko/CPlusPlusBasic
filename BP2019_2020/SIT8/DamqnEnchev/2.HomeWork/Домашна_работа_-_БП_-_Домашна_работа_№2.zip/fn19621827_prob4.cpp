#include <iostream>
using namespace std;
int shop1(int a, int b, int c);
int shop2(int a, int b, int c);
int shop3(int a, int b, int c);
int main()
{
	int a;
	int b;
	int c;

	int x;
	int y;
	int z;

	a = 8;
	b = 3;
	c = 7;
	x = shop1(a,b,c);
	y = shop2(b, a, c);
	z = shop3(c, b, c);
	
	return 0;

}

int shop1(int a, int b, int c)
{
	int x;
	x = a;
	cout << x << endl;
	return x;
}
int shop2(int a, int b, int c)
{
	int y;
	y = b;
	cout << y << endl;
	return y;
}
int shop3(int a, int b, int c)
{
	int z;
	z = c;
	cout << z << endl;
	return z;
}
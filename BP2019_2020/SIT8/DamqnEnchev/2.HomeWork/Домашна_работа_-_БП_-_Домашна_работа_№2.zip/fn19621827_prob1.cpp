#include <iostream>
using namespace std;
int show(int a, int b);

int main()
{
	cout << "Start ?" << endl;
	system("pause");
	cout << "Final !" << endl;
	return 0;
}

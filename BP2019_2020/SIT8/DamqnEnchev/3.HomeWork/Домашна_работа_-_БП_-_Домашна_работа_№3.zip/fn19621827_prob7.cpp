#include <iostream>
#include <math.h>

using namespace std;

int show(double y);

int main()
{
	double y;
	double x;
	cout << "Enter y!" << endl;
	cin >> y;
	x = show(y);

	return 0;
}
int show(double y)
{
	double x;
	if (y<-5)
	{
		cout << "x = y3 + (y4 + 2y)=" << (x = (pow(y, 3) + (pow(y, 4) + 2 * y))) << endl;
		return x;
	}
	else if (y > -5)
	{
		cout << "x=2(2y + 5)/(14 - y/3)=" << (x = 2 * (2 * y + 5) / (14 - y / 3)) << endl;
		return x;

	}
}
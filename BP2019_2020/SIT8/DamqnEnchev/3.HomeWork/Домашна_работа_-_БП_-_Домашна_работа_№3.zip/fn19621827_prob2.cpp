#include <iostream>
using namespace std;
int bobobo(int a, int b);
int main()
{
	int a, b;
	cout << "Enter a!" << endl;
	cout << "a=";
	cin >> a;
	cout << "Enter b!" << endl;
	cout << "b=";
	cin >> b;
	cout << "Bigger value=" <<  bobobo(a, b) << endl;
	return 0;
}
int bobobo(int a, int b)
{
	if (a > b)
	{
		return a;
	}
	else
	{
		return b;
	}

}
#include <iostream>
using namespace std;
int number(int x);
int main()
{
	int y;
	int x;
	cout << "Enter number!" << endl;
	cout << "Number=";
	cin >> x;
	y = number(x);

	return 0;
}
int number(int x)
{
	int y;
	if (y=x % 2 != 0)
	{
		cout << "Odd" << endl;
		return x;
	}
	else if (y=x % 2 == 0)
	{
		cout << "Even" << endl;
		return x;
	}
	return 0;
}

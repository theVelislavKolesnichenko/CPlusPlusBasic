#include <iostream>
using namespace std;
int kid(int y);
int main()
{
	int y;
	int x; 
	cout << "Enter age!" << endl;
	//y=age
	cout << "Age=";
	cin >> y;
	x = kid(y);

	return 0;
}
int kid(int y)
{
	int x;
	if (y > 0 && y < 1)
	{
		cout << "Baby" << endl;
		return 0;
	}
	else if (y >= 1 && y < 3)
	{
		cout << "Toddler" << endl;
		return 0;
	}
	else if (y >= 3 && y < 5)
	{
		cout << "Preschool" << endl;
		return 0;
	}
	else if (y >= 5 && y <= 12)
	{
		cout << "Gradeschooler" << endl;
		return 0;
	}
	else if (y >= 13 && y < 18)
	{
		cout << "Teen" << endl;
		return 0;
	}
	else if (y >= 18 && y < 21)
	{
		cout << "Young Adult" << endl;
		return 0;
	}

	return 0;

}
#include <iostream>
using namespace std;
int abc(char ch);
int main()
{
	char ch;
	cout << "Letter=" << endl;
	cin >> ch;
	cout << abc(ch) << endl;

	return 0;
}
int abc(char ch)
{
	int a, A, b, B, c, C, d, D, e, E, f, F, g, G, h, H, i, I, j, J, k, K, l, L, m, M, n, N, o, O, p, P, q, Q, r, R, s, S, t, T, u, U, v, V, w, W, x, X, y, Y, z, Z;

	switch (ch)
	{
	case 'a':
	{
		a = 1;
	}
	break;
	case 'A':
	{
		a = 1;
	}
	case 'b':
	{
		a = 2;
	}
	break;
	case 'B':
	{
		a = 2;
	}
	case 'c':
	{
		a = 3;
	}
	break;
	case 'C':
	{
		a = 3;
	}
	case 'd':
	{
		a = 4;
	}
	break;
	case 'D':
	{
		a = 4;
	}
	case 'e':
	{
		a = 5;
	}
	break;
	case 'E':
	{
		a = 5;
	}
	case 'f':
	{
		a = 6;
	}
	break;
	case 'F':
	{
		a = 6;
	}
	case 'g':
	{
		a = 7;
	}
	break;
	case 'G':
	{
		a = 7;
	}
	case 'h':
	{
		a = 8;
	}
	break;
	case 'H':
	{
		a = 8;
	}
	case 'i':
	{
		a = 9;
	}
	break;
	case 'I':
	{
		a = 9;
	}
	case 'j':
	{
		a = 10;
	}
	break;
	case 'J':
	{
		a = 10;
	}
	case 'k':
	{
		a = 11;
	}
	break;
	case 'K':
	{
		a = 11;
	}
	case 'l':
	{
		a = 12;
	}
	break;
	case 'L':
	{
		a = 12;
	}
	case 'm':
	{
		a = 13;
	}
	break;
	case 'M':
	{
		a = 13;
	}
	case 'n':
	{
		a = 14;
	}
	break;
	case 'N':
	{
		a = 14;
	}
	case 'o':
	{
		a = 15;
	}
	break;
	case 'O':
	{
		a = 15;
	}
	case 'p':
	{
		a = 16;
	}
	break;
	case 'P':
	{
		a = 16;
	}
	case 'q':
	{
		a = 17;
	}
	break;
	case 'Q':
	{
		a = 17;
	}
	case 'r':
	{
		a = 18;
	}
	break;
	case 'R':
	{
		a = 18;
	}
	case 's':
	{
		a = 19;
	}
	break;
	case 'S':
	{
		a = 19;
	}
	case 't':
	{
		a = 20;
	}
	break;
	case 'T':
	{
		a = 20;
	}
	case 'u':
	{
		a = 21;
	}
	break;
	case 'U':
	{
		a = 21;
	}
	case 'v':
	{
		a = 22;
	}
	break;
	case 'V':
	{
		a = 22;
	}
	case 'w':
	{
		a = 23;
	}
	break;
	case 'W':
	{
		a = 23;
	}
	case 'x':
	{
		a = 24;
	}
	break;
	case 'X':
	{
		a = 24;
	}
	case 'y':
	{
		a = 25;
	}
	break;
	case 'Y':
	{
		a = 25;
	}
	case 'z':
	{
		a = 26;
	}
	break;
	case 'Z':
	{
		a = 26;
	}



	default:
	{
		a = 0;
	}
	break;

	}
	return a;

	}
#include <iostream>
using namespace std;
int main()
{
	double a;
	cout << "Choose a number!" << endl;
	cin >> a;
	{

		if (a > 0)
		{
			cout << "Positive" << endl;
		}
		else
		{
			cout << "Negative" << endl;
		}
	}
}

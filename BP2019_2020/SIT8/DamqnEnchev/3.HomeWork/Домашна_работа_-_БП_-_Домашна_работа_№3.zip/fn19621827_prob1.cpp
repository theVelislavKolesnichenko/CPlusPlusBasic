#include <iostream>
using namespace std;
int blabla(int a, int b);
int main()
{
	int a;
	int b;
	int x;
	cout << "Enter a!" << endl;
	cout << "a=";
	cin >> a;
	cout << "Enter b!" << endl;
	cout << "b=";
	cin >> b;
	x = blabla(a, b);
	return 0;
}
int blabla(int a, int b)
{
	cout << "~a=" << (~a) << endl;
	cout << "a & b=" << (a & b) << endl;
	cout << "a | b=" << (a | b) << endl;
	cout << "a ^ b=" << (a ^ b) << endl;
	cout << "a << 5 =" << (a << 5) << endl;
	cout << "b << 5 =" << (b << 5) << endl;
	cout << "a >> 4=" << (a >> 4) << endl;
	cout << "b >> 4=" << (b >> 4) << endl;
	return 0;
}
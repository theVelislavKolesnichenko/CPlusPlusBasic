#include <iostream>
using namespace std;
int bo(int y);
int main()
{
	int y;
	int X;
	cin >> y;
	cout << X << endl;
	X = bo(y);
	return 0;

}
int bo(int y)
{
	int X;
	if (y == 0)
	{
		cout << "Not divisible by 0" << endl;
	}
	else if (y>0)
	{
		return X = 20 / y;
	}
	return 0;
}
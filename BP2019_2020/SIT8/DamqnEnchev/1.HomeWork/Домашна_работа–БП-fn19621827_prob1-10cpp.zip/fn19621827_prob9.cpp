#include <iostream>
using namespace std;
int main()
{
	int b;
	int hb;
	int S;

	cout << "Enter b" << endl;
	cin >> b;
	cout << "Enter hb" << endl;
	cin >> hb;

	S = (b * hb) / 2;
	
	cout << "S=(b*hb)/2=" << S << endl;

	return 0;

}
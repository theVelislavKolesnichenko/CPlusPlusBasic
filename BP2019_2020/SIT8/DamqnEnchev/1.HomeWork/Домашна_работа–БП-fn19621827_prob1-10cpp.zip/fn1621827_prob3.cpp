#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	int A;
	int B;
	int C;
	A = 5;
	B = 7;
	C = 6;
	cout << "Units" << setw(2) << A << setw(5) << "Tens" << setw(2) << B << setw(9) << "Hundreds" << setw(2) << C << endl;

	return 0;
	
}
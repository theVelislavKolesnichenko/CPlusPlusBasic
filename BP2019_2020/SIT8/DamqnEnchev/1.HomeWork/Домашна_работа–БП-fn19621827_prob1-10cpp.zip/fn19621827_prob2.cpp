#include <iostream>
# include <math.h>
using namespace std;
#define AVRG (A+B+C)/3 
int main()
{
	int A, B, C;
	cout << "Enter A" << endl;
	cin >> A;
	cout << "Enter B" << endl;
	cin >> B;
	cout << "Enter C" << endl;
	cin >> C;
	cout << "AVRG(A, B, C)=" << AVRG << endl;
	return 0;
}
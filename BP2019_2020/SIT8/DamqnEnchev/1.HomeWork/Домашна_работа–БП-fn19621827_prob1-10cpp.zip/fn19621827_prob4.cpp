#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	cout << "Rank" << setw(10) << "Gymnasty" << setw(18) << "Nation" << setw(15) << "Ribbon" << setw(15) << "Ball" << setw(15) << "Batons" << setw(15) << "Hoop" << setw(15) << "Total" << endl;
	cout << "1" << setw(17) << "Dina Averina" << setw(14) << "Russia" << setw(15) << "21.650" << setw(17) << "22.950" << setw(13) << "23.000" << setw(17) << "23.800" << setw(14) << "91.400" << endl;
	cout << "2" << setw(18) << "Arina Averina" << setw(13) << "Russia" << setw(15) << "20.850" << setw(17) << "23.100" << setw(13) << "24.050" << setw(17) << "23.100" << setw(14) << "91.100" << endl;
	cout << "3" << setw(17) << "Linoy Ashram" << setw(14) << "Israel" << setw(15) << "21.050" << setw(17) << "23.100" << setw(13) << "23.500" << setw(17) << "22.050" << setw(14) << "89.700" << endl;
	cout << "4" << setw(19) << "Boryana Kaleyn" << setw(14) << "Bulgaria" << setw(13) << "19.900" << setw(17) << "22.400" << setw(13) << "22.350" << setw(17) << "21.625" << setw(14) << "86.275" << endl;
	cout << "5" << setw(22) << "Vlada Nikolchenko" << setw(12) << "Ukraine  " << setw(12) << "19.450" << setw(17) << "22.250" << setw(13) << "19.500" << setw(17) << "22.950" << setw(14) << "84.150" << endl;
	cout << "==============================================================================================================" << endl;
	cout << "Rank  Gymnast             Nation    Ribbon  Ball    Batons  Hoop    Total" << endl;
	cout << "1     Dina Averina        Russia    21.650  22.950  23.000  23.800  91.400" << endl;
	cout << "2     Arina Averina       Russia    20.850  23.100  24.050  23.100  91.100" << endl;
	cout << "3     Linoy Ashram        Israel    21.050  23.100  23.500  22.050  89.700" << endl;
	cout << "4     Boryana Kaleyn      Bulgaria  19.900  22.400  22.350  21.625  86.275" << endl;
	cout << "5     Vlada Nikolchenko   Ukraine   19.450  22.250  19.500  22.950  84.150" << endl;

	return 0;

}
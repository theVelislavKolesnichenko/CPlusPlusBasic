#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	float A;
	float C;
	float Y;
	cout << "Enter A" << endl;
	cin >> A;
	cout << "Enter C" << endl;
	cin >> C;
	Y = sqrt(A + 2) - (C*2);
	cout << "Y=sqrt(A+2)-C*2=" << Y << endl;

	return 0;

}
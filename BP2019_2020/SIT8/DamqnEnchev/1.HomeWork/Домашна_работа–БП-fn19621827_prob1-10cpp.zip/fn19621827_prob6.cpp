#include <iostream>
using namespace std;
#include <math.h>
int main()
{
	int A;
	int B;
	int C;
	int Z;
	cout << "Enter A" << endl;
	cin >> A;
	cout << "Enter B" << endl;
	cin >> B;
	cout << "Enter C" << endl;
	cin >> C;
	Z = 2 * (A - B) * (A - C);
	cout << "Z=2(A-B)*(A-C)=" << Z << endl;

	return 0;
	
}
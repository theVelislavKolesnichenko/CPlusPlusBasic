#include <iostream>
using namespace std;
int main()
{
	int a;
	int b;
	int S;
	int P;

	cout << "Enter a" << endl;
	cin >> a;

	cout << "Enter b" << endl;
	cin >> b;

	S = a * b;
	P = 2 * (a + b);

	cout << "S=a*b=" << S << endl;
	cout << "P=2*(a+b)=" << P << endl;

	return 0; 


}
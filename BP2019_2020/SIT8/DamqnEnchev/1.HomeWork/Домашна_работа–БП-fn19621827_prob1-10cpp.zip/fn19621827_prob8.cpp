#include <iostream>
using namespace std;
int main()
{
	float X;
	float Y;
	cout << "Enter Y" << endl;
	cin >> Y;
	X = (2*Y + 5) / (14 - Y / 3);
	cout << "X=(2*Y+5)/(14-Y/3)=" << X << endl;

	return 0;

 }
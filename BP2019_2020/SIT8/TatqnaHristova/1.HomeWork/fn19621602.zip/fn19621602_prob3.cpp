#include <iostream>
using namespace std;

int main()
{
	int Units = 6, Tens = 7, Hundreds = 5;
	cout <<"Units "<< Units<<"\tTens "<< Tens<<"\tHundreds "<< Hundreds<< endl;

	return 0;
}
#include <iostream>
using namespace std;

void printStart() {
	cout << "Start ?";
}

void printFinal() {
	cout << "Final !";
}
int main()
{
	printStart();
	system("pause");
	printFinal();

	return 0;
}
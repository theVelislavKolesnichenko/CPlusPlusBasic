#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	int a = 8;
	int c = 6;
	int y;
	cout << "a=" << a << endl;
	cout << "c=" << c << endl;
	cout << "y=sqrt(a+2)-c*2" << endl;
	y = sqrt(a + 2) - c * 2;
	cout << "y=" << y << endl;
	return 0;

}

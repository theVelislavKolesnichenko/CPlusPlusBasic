#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	cout << "Rank" << setw(10) << "Gymnasty" << setw(17) << "Nation" << setw(10) << "Ribbon" << setw(10) << "Ball" << setw(10) << "Batons" << setw(10) << "Hoop" << setw(10) << "Total";
	cout << "\n1" << setw(17) << "Dina Averina" << setw(13) << "Russia" << setw(10) << "21.650" << setw(12) << "22.950" << setw(8) << "23.000" << setw(12) << "23.800" << setw(9) << "91.400";
	cout << "\n2" << setw(18) << "Arina Averina" << setw(12) << "Russia" << setw(10) << "20.850" << setw(12) << "23.100" << setw(8) << "24.050" << setw(12) << "23.100" << setw(9) << "91.100";
	cout << "\n3" << setw(17) << "Linoy Ashram" << setw(13) << "Israel" << setw(10) << "21.050" << setw(12) << "23.100" << setw(8) << "23.500" << setw(12) << "22.050" << setw(9) << "89.700";
	cout << "\n4" << setw(19) << "Boryana Kaleyn" << setw(13) << "Bulgaria" << setw(8) << "19.900" << setw(12) << "22.400" << setw(8) << "22.350" << setw(12) << "21.625" << setw(9) << "86.275";
	cout << "\n5" << setw(22) << "Vlada Nikolchenko" << setw(9) << "Ukraine" << setw(9) << "19.450" << setw(12) << "22.250" << setw(8) << "19.500" << setw(12) << "22.950" << setw(9) << "84.150";
}

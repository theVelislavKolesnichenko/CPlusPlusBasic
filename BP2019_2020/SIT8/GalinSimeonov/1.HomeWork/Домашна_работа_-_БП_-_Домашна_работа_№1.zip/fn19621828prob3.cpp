#include <iostream>
using namespace std;
int main()
{
	int a = 6;
	int b = 7;
	int c = 5;
	cout << c << b << a << endl;
	cout << "Units" << a << "\nTens" << b << "\nHundreds" << c << endl;
	return 0;
}
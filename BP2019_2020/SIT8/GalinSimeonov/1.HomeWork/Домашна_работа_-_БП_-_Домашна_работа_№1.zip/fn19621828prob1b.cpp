#include <iostream>
using namespace std;
int main()
{
	float a = 22.65;
	int b = 5;
	double d;
	cout << "a=" << a << endl;
	cout << "b=" << b << endl;
	d = a / b;
	cout << "d=" << d << endl;

	return 0;

}
#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	int s;
	int a = 8;
	int ha = 2;
	s = a * ha / 2;
	cout << "S=a*ha/2" << endl;
	cout << "S=" << s << endl;
	return 0;
}
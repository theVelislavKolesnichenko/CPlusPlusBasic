#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	int a = 9;
	int b = 6;
	int S;
	int P;
	cout << "P=2*(a+b)" << endl;
	cout << "S=a*b" << endl;
	P = 2 * (a + b);
	cout << "P=" << P << endl;
	S = a * b;
	cout << "S=" << S << endl;
	return 0;

}
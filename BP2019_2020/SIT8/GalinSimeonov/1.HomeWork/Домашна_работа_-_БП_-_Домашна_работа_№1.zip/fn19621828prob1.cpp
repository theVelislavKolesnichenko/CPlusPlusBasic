#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	double a=7, b=2, c;
	cout << "a=" << a << endl;
	cout << "b=" << b << endl;
	cout << "c=a/b" << endl;
	c = a / b;
	cout << "c=" << c << endl;
		return 0;
}
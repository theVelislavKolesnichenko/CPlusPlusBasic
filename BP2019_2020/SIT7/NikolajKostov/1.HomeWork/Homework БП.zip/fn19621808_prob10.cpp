#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	double a, b;
	cout << "Please input a number for a" << endl;
	cin >> a;
	cout << "Please input a number for b" << endl;
	cin >> b;
	cout << "P=" << (2) * (a + b) << endl;
	cout << "S=" << (a * b) << endl;

	return 0;
}
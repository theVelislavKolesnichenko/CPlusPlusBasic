#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	int a, b, c, z;
	cout << "Please input a number for 'a'" << endl;
	cin >> a;
	cout << "Please input a number for 'b'" << endl;
	cin >> b;
	cout << "Please input a number for 'c'" << endl;
	cin >> c;
	cout << "z=2(a-b)(a-c) ---> z=2(" << a << "-" << b << ")(" << a << "-" << c << ")=" << 2 * (a - b) * (a - c) << endl;

	return 0;
}
#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	double a, c;
	cout << "Please input a number for 'a'" << endl;
	cin >> a;
	cout << "Please input a number for 'c'" << endl;
	cin >> c;
	cout << "y=sqrt(a+2)-c2 --->" << "y=sqrt(" << a << "+2)-" << c << "2=" << sqrt(a + 2) - c * 2 << endl;

	return 0;
}
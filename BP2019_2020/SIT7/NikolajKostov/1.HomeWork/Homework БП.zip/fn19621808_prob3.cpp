#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	int ones = 576 % 10, tens = (576 / 10) % 10, hundreds = (576 / 100) % 10;
	cout << "576 has:" << endl;
	cout << "Units=" << ones << endl;
	cout << "Tens=" << tens << endl;
	cout << "Hundreds=" << hundreds << endl;

	return 0;
}
#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	double a, b;
	cout << "Please input a number for a" << endl;
	cin >> a;
	cout << "Please input a number for b" << endl;
	cin >> b;
	cout << "S=" << a << "*" << b << "/2 --->" << "S=" << (a * b) / (2) << endl;

	return 0;
}
#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	int a, b;
	cout << "Pleade input a number for 'a'" << endl;
	cin >> a;
	cout << "Please input a number for 'b'" << endl;
	cin >> b;
	cout << "c=a/b --->" << "c=" << a << "/" << b << "=" << a / b << endl;
	cout << "c=" << (double)a / b << endl;
	//In the first problem we only use the 'int' on the input number. In the second problem we use 'double' on the actual calculating.

	return 0;
}
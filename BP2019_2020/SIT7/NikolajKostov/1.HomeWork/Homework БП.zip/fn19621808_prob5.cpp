﻿#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	cout << "а)  %%%%%   b)  %       c)  %       d)  %%%%%%%%%%" << endl;
	cout << "    %%%%        %%          %%           %%%%%%%%" << endl;
	cout << "    %%%         %%%         %%%           %%%%%%" << endl;
	cout << "    %%          %%          %%%%           %%%%" << endl;
	cout << "    %           %           %%%%%           %%" << endl;

	return 0;
}
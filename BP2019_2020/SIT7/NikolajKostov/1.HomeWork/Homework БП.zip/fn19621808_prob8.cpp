#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	double y;
	cout << "Please input a number for y" << endl;
	cin >> y;
	cout << "x=" << (double)((2 * y) + 5) / (double)(14 - (y / 3)) << endl;
	return 0;
}
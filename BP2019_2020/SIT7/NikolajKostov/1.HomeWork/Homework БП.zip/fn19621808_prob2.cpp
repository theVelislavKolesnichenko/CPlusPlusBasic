#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	int a, b, c;
	cout << "Please input three numbers for finding their average number." << endl;
	cout << "Please input the first number:" << endl;
	cin >> a;
	cout << "Please input the second number:" << endl;
	cin >> b;
	cout << "Please input the third number:" << endl;
	cin >> c;
	cout << "The average is:" << (double)(a + b + c) / 3 << endl;

	return 0;
}
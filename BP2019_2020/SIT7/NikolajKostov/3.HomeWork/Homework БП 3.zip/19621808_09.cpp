#include <iostream>

using namespace std;

int main()
{
	cout << "How old is your child? A child is considered to be a child up to 21 years." << endl;
	int ChildY;
	cout << "Child years = ";
	cin >> ChildY;
	if (ChildY == 0 && ChildY < 1)
		cout << "Your child is considered a baby" << endl;
	if (ChildY >= 1 && ChildY < 3)
		cout << "Your child is conidered a toddler" << endl;
	if (ChildY >= 3 && ChildY < 5)
		cout << "Your child is considered a preschool" << endl;
	if (ChildY >= 5 && ChildY <= 12)
		cout << "Your child is considered a gradeschooler" << endl;
	if (ChildY >= 13 && ChildY < 18)
		cout << "Your child is considered a teen" << endl;
	if (ChildY >= 18 && ChildY < 21)
		cout << "Your child is cinsidered a young adult" << endl;

	return 0;
 }
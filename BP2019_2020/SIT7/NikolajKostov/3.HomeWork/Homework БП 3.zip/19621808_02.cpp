#include <iostream>

using namespace std;

int main()
{
	int a, b;
	cout << "Please input 2 numbers to check if the function 'if' works fine" << endl;
	cout << "a=";
	cin >> a;
	cout << "b=";
	cin >> b;
	if (a > b)
		cout << a << " > " << b << endl;
	if (a < b)
		cout << a << " < " << b << endl;
	if (a = b)
		cout << a << " = " << b << endl;

	return 0;
}
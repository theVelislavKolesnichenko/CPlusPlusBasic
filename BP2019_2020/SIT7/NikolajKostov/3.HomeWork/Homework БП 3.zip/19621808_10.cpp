#include <iostream>

using namespace std;

int main()
{
	int y;
	cout << "Please input a number for checking if it's 'even' or 'odd' number." << endl;
	cout << "y=";
	cin >> y;
	if (y % 2 == 0)
		cout << y << " is even." << endl;
	else
		cout << y << " is odd." << endl;

	return 0;
}
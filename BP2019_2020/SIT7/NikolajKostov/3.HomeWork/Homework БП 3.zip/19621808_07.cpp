#include <iostream>

using namespace std;

int main()
{
	int y;
	cout << "Please input a number for 'y'" << endl;
	cout << "y=";
	cin >> y;
	if (y <= -5)
		cout << "x=" << (y * y * y) + (y * 4 + 2 * y) << endl;
	else if (y > 5)
		cout << "x=" << 2 * (2 * y + 5) / (14 - y / 3) << endl;
	else
		cout << "'y' cannot be -4;-3;-2;-1;0;1;2;3;4;5" << endl;

	return 0;
}
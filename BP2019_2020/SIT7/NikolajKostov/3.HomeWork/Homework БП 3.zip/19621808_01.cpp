#include <iostream>

using namespace std;

int main()
{
	int a, b;
	cout << "Please input 2 numbers for checking the binary functions." << endl;
	cout << "a=";
	cin >> a;
	cout << "b=";
	cin >> b;
	cout << (~a) << endl; 
	cout << (a & b) << endl;
	cout << (a | b) << endl;
	cout << (a ^ b) << endl;
	cout << (a << 5) << endl;
	cout << (b >> 4) << endl;

	return 0;
}
#include <iostream>
#include <math.h>

using namespace std;

int main()
{
	int y;
	cout << "Please input a number for 'y'" << endl;
	cout << "y=";
	cin >> y;
	if (y < 1)
		cout << "x=" << (y*y*y) + ((y*y*y*y) + 2 * y) << endl;
	if (y > 1)
		cout << "x=" << 2*(2*y + 5) / (14 - y / 3) << endl;
	if (y == 1)
		cout << "'y' cannot be 1" << endl;

	return 0;
}
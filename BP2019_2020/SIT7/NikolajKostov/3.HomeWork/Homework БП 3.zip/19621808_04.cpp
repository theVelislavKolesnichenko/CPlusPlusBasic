#include <iostream>

using namespace std;

int main()
{
	int y;
	cout << "Please input a number for 'y'" << endl;
	cout << "y=";
	cin >> y;
	if (y == 0)
		cout << "'y' cannot be 0" << endl;
	cout << "x=20/" << y << "      x=" << 20 / y << endl;

	return 0;
}
#include <iostream>

using namespace std;

int main()
{
	int N;
	cout << "Please input a number to check if it's negative or positive" << endl;
	cout << "N=";
	cin >> N;
	if (N < 0)
		cout << "The number is negative" << endl;
	if (N > 0)
		cout << "The number is positive" << endl;

	return 0;
}
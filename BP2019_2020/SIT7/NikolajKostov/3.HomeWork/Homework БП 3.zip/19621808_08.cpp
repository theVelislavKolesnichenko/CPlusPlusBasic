#include <iostream>

using namespace std;

int main()
{
	cout << "Please input a number between 1 and 26 to show their matching letter" << endl;
	int alphabet;
	cin >> alphabet;
	switch (alphabet)
	{
	case 1:
		cout << "1 - a" << endl;
		break;
	case 2:
		cout << "2 - b" << endl;
		break;
	case 3:
		cout << "3 - c" << endl;
		break;
	case 4:
		cout << "4 - d" << endl;
		break;
	case 5:
		cout << "5 - e" << endl;
		break;
	case 6:
		cout << "6 - f" << endl;
		break;
	case 7:
		cout << "7 - g" << endl;
		break;
	case 8:
		cout << "8 - h" << endl;
		break;
	case 9:
		cout << "9 - i" << endl;
		break;
	case 10:
		cout << "10 - j" << endl;
		break;
	case 11:
		cout << "11 - k" << endl;
		break;
	case 12:
		cout << "12 - l" << endl;
		break;
	case 13:
		cout << "13 - m" << endl;
		break;
	case 14:
		cout << "14 - n" << endl;
		break;
	case 15:
		cout << "15 - o" << endl;
		break;
	case 16:
		cout << "16 - p" << endl;
		break;
	case 17:
		cout << "17 - q" << endl;
		break;
	case 18:
		cout << "18 - r" << endl;
		break;
	case 19:
		cout << "19 - s" << endl;
		break;
	case 20:
		cout << "20 - t" << endl;
		break;
	case 21:
		cout << "21 - u" << endl;
		break;
	case 22:
		cout << "22 - v" << endl;
		break;
	case 23:
		cout << "23 - w" << endl;
		break;
	case 24:
		cout << "24 - x" << endl;
		break;
	case 25:
		cout << "25 - y" << endl;
		break;
	case 26:
		cout << "26 - z" << endl;
		break;
	default:
		cout << "The number MUST BE between 1 and 26!" << endl;
		break;
	}

	return 0;
}
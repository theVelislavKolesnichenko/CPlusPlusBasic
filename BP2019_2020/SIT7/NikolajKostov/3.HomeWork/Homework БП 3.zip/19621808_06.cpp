#include <iostream>

using namespace std;

int main()
{
	int y;
	cout << "Please input a number for 'y'" << endl;
	cout << "'y' must be >=58 && <=87, OR >15 && <58" << endl;
	cout << "y=";
	cin >> y;
	if (y >= 58 && y <= 87)
		cout << "x=" << (y * y * y) + (y * 4 + 2 * y) << endl;
	else if (y > 15 && y < 58)
		cout << "x=" << 2 * (2 * y + 5) / (14 - y / 3) << endl;
	else
		cout << "'y' has to be between the shown numbers!" << endl;

	return 0;
}
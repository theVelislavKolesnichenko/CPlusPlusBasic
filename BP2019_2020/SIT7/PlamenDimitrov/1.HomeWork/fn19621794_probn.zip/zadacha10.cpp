#include <iostream>
using namespace std;

int main()
{
	int a,b;
	
	cout<<"a=";
	cin>>a;
	cout<<"\n b=";
	cin>>b;
	
	int p= (2*a) + (2*b);
	int s = a*b;
	cout<<"\n p="<<p;
	cout<<"\n s="<<s<<endl;
	 system ("pause");
}
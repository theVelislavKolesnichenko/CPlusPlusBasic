#include <iostream>
using namespace std;
int main()
{
	float a,b;

	cout<<"a=";
	cin>>a;
	cout<<"\n b=<<";
	cin>>b;
	float c=a/b;
	cout<<"\n c="<<c;

	system ("pause");
}
#include <iostream>
using namespace std;

void main()
{
	int u, t, h;
	int a = 576;

	u = (a/100)%10;
	t = (a/10)%10;
	h = (a%10);

	cout<<a<<endl;
	cout<<"Units="<<u<<" Tens="<<t<<"Hundreds="<<h;
	
	system ("pause")

}
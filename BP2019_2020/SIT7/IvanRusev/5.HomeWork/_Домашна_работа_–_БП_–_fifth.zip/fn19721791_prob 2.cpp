#include <iostream>
using namespace std;
int numbers(double a);
int main()
{
	double a = 0;
	cout << "Enter a numbersbetween -2147483648 and 2147483647.";
	do
	{
		cin >> a;
		
	} while (a <= (214748364)&&(a> 2147483648));
	cout<<numbers(a)<<"digits";


}
int numbers(double a)
{
	int number = 0;
	if (a < 0) 
	{
		for (int i = 0; a > -1; i++)
		{
			a = a / 10;
			number++;
		}

	}
	else
	{
		{
			for (int i = 0; a > +1; i++)
			{
				a = a / 10;
				number++;
			}

		}
	}
return number;
}
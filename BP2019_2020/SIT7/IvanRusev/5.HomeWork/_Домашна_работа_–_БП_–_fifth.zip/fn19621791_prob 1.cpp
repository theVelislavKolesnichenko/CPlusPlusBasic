#include <iostream>
using namespace std;
double combined(double a);
int main()
{
	double a = 0;
	cout << "Enter possitive numbers.The numbers will be combined when 0 or a negative number  is inputed.";
	
	cout << "total ="<<combined(a);
	
	
}
double combined(double a)
{
	double combined = 0;
	do
	{
		cin >> a;
		if (a < 0)
		{
			break;
		}
		combined = combined += a;
	} while (a != 0);

	return(combined);
}
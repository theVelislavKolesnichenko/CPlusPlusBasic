#include <iostream>
#include <math.h>
using namespace std;
double opr(double a,double b);
int main()
{
	double a,b;
	do {
		cout << "insert a";
		cin >> a;
		cout << "insert b";
		cin >> b;
		if (a <= 0 || b <= 0)
		{
			cout << "no\n";
		}
		else
		{
			continue;
		}
	}
	while (a<=0||b<=0);
	cout << opr(a, b);
	return 0;
}
double opr(double a, double b)
{
	double y = sqrt(a + 2) - 2 / b;
		return y;
}
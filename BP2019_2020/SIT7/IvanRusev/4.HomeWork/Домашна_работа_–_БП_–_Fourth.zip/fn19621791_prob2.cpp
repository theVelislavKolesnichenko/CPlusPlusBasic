#include <iostream>
using namespace std;
void month(int a);
int main()
{
	int a;
	cout << "month number?";
	cin >> a;
	month(a);
}
void month(int a)
{
	do {
		switch (a)
		{
		case 3:
		case 4:
		case 5:
			cout << "spring";
				break;

		case 6:
        case 7:
        case 8:
			cout << "summer";
				break;

		case 9:
        case 10:
        case 11:
			cout << "fall";
				break;
		case 12:
        case 1:
        case 2:
			cout << "winter";
				break;
		default:
		 cout << "not a month";

				break;
		}
	} while (a < 0 && a<=12);
}

#include <iostream>
using namespace std;
void delitel(int a, int b);
void kratno(int a, int b);
int main()
{
	int a, b;
	cout << "a=\n";
	cin >> a;
	cout << "b=\n";
	cin >> b;
	delitel(a, b);
	kratno(a, b);
	return 0;
}
void delitel(int a, int b)
{
	int i;
	(a - b > 0) ? i = b: i = a;
	for ( i ; i> 0; i--) 
	{
		if (0 == a % i && 0 == b % i) {
			cout << "nod" << i<< endl;
		}
	}
	
}
void kratno(int a, int b)
{
	int i;
	(a - b > 0) ? i = b : i = a;
	for (i; i > 0; i++)
	{
		if (0 == a % i && 0 == b % i) {
			cout << "nok" << i << endl;
			break;
		}
	}

}
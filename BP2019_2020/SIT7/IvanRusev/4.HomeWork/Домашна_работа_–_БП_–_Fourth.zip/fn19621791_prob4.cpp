#include <iostream>
#include <math.h>
using namespace std;
double opr(double a, double b,double c);
int main()
{
	double a, b, c;
	cout << "a";
	cin >> a;
	cout << "b";
	cin >> b;
	cout << "c";
	cin >> c;
	opr(a, b, c);
	return 0;
}
double opr(double a, double b, double c)
{
	
	double dis = pow(b*-1, 2) * -4 * a * c;
	double x1 = b * -1 + sqrt(dis) / 2;
	double x2 = b * -1 - sqrt(dis) / 2;
	if (dis > 0)
	{
		cout << "x1=" << x1 / 2 << "x2=" << x2;
	}
	else if(dis<0)
	{
		cout << "no x";
	}
	else
	{
		(pow(a, x1) + 2 * b * x1 + c ==0) ? cout << x1 :cout << x2;
	}
	return 0;
}
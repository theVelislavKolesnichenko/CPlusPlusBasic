#include <iostream>
#include <math.h>
using namespace std;
void count(int a);
int main()
{
	int a;
	cout << "insert a";
	cin >> a;
	count(a);
	return 0;
}
void count(int a)
{

	for (int i = 0; i <= a; i++)
	{
	int count =+ i;
	   cout << count;
	}
	
}
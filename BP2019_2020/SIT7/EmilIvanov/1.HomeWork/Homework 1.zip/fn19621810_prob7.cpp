#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	int a;
	int c;
	cout << "Insert a value of a and c" << endl;
	cin >> a;
	cin >> c;
	cout << "y=" << sqrt(a + 2) - (c*2) << endl;
	return 0;
}
#include <iostream>
using namespace std;
int main()
{
	cout << "Rank  Gymnast             Nation    Ribbon  Ball    Batons  Hoop    Total " << endl;
	cout << "1     Dina Averina        Russia    21.650  22.950  23.000  23.800  91.400" << endl;
	cout << "2     Arina Averina       Russia    20.850  23.100  24.050  23.100  91.100" << endl;
	cout << "3     Linoy Ashram        Israel    21.050  23.100  23.500  22.050  89.700" << endl;
	cout << "4     Boryana Kaleyn      Bulgaria  19.900  22.400  22.350  21.625  86.275" << endl;
	cout << "5     Vlada Nikolchenko   Ukraine   19.450  22.250  19.500  22.950  84.150" << endl;
	return 0;
}
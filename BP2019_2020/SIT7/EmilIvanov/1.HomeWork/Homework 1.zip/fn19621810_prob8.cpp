#include <iostream>
using namespace std;
int main()
{
	int y;
	cout << "Insert a value of y" << endl;
	cin >> y;
	cout << "x=" << (float)((2*y)+5)/(14-(y/3))<< endl;
	return 0;
}
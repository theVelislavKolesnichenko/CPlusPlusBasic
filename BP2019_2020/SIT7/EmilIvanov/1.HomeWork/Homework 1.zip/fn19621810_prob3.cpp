#include <iostream>
using namespace std;
int main()
{
	int ones = 576 % 10;
	int tens = (576 / 10) % 10;
	int hundreds = (576 / 100) % 10;
	cout << "576 has:" << endl;
	cout <<"Units="<< ones << endl;
	cout <<"Tens="<< tens << endl;
	cout <<"Hundreds="<< hundreds << endl;
	return 0;
}
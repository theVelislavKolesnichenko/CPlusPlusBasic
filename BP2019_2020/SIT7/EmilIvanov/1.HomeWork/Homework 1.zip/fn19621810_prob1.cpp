#include <iostream>
using namespace std;
	int main()
	{
		int a;
		int b;
		cout << "Insert a value of a and b" << endl;
		cin >>a;
		cin >> b;
		cout << "c=" <<(float) a / b << endl;//The result from dividing an int type number by an int type number is a float type number 
		return 0;
	}
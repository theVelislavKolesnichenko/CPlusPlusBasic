#include <iostream>
using namespace std;
int main()
{
	int a;
	int h;
	cout << "Insert a value of a and h to get S" << endl;
	cin >> a;
	cin >> h;
	cout << "S=" << (a * h) / (2) << endl;
	return 0;
}
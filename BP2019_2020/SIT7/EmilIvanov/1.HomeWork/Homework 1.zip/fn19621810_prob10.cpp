#include <iostream>
using namespace std;
int main()
{
	int a;
	int b;
	cout << "Insert a value of a and b" << endl;
	cin >> a;
	cin >> b;
	cout << "P=" << (2) * (a + b) << endl;
	cout << "S=" << (a * b) << endl;
	return 0;
}
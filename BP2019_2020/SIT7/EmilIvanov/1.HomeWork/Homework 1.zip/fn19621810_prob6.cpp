#include <iostream>
using namespace std;
int main()
{
	int a;
	int b;
	int c;
	cout << "Insert a value of a, b and c" << endl;
	cin >> a;
	cin >> b;
	cin >> c;
	cout << "z=" <<(int) (2)*(a - b)*(a - c) / 3 << endl;
	return 0;
}
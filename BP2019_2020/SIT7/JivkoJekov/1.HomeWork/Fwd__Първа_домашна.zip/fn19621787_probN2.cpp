#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	float a;
	float b;
	float c;
	cout << "Vuvedete a=";
	cin >> a;
	cout << "Vuvedete b =";
	cin >> b;
	cout << "Vuvedete c =";
	cin >> c;
	cout << "(a+b+c)/3=" << (a + b + c) / 3;
	return 0;
}

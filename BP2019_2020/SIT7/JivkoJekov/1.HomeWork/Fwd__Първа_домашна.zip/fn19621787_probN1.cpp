﻿#include<iostream>
#include<math.h>
#include<iomanip>
using namespace std;
int main()
{
	float a;
	int b;
	int c = a/b;
	cout << "въведете a=";
	cin >> a;
	cout << "въведете b=";
	cin >> b;
	cout << "c= a/b" << a / b;
	cin >> c;


	

	return 0;
}
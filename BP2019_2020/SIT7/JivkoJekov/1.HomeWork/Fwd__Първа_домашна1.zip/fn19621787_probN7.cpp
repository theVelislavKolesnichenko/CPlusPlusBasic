﻿#include<iostream>
using namespace std;
int main()
{
	int y, a, c, ;
	cout << "Въведете стойност а=";
	cin >> a;
	cout << "Въведете стойност c";
	cin >> c
		𝑦 = √(𝑎 + 2)−𝑐2
		cout << "y=" << y = << y << endl;
		return 0;
}

#include<iostream>
using namespace std;
int abc(char ch);
int main()
{
	char c;
	cout << "char=";
	cin >> c
		cout << abv(c) << endl;
	return 0;
}
int abv(char ch);
{
	int a;
	switch (ch)
}
case a;
	}
	a = 1;
	{

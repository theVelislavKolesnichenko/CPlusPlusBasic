#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	int a, b, c;
	int avg;
	cin >> a;
	cin >> b;
	cin >> c;
	avg = (a + b + c) / 3;
	cout << avg<<endl;
	system("pause");
	return 0;
}
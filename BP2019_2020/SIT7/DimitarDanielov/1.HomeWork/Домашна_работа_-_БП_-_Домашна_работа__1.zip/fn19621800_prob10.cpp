#include <iostream>
using namespace std;
int main()
{
	int a, b, S, P;
	cout << "a=";
	cin >> a;
	cout << "b=";
	cin >> b;
	S = a*b;
	P = 2 * a + 2 * b;
	cout << "P=" << P << endl;
	cout << "S=" << S << endl;
	system("pause");
	return 0;
}
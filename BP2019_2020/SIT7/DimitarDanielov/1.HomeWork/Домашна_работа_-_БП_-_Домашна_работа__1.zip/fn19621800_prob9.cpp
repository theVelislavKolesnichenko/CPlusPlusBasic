#include <iostream>
using namespace std;
int main()
{
	int a, h, S;
	cout << "a=";
	cin >> a;
	cout << "h=";
	cin >> h;
	S = (a*h) / 2;
	cout << "S=" << S << endl;
	system("pause");
	return 0;
}


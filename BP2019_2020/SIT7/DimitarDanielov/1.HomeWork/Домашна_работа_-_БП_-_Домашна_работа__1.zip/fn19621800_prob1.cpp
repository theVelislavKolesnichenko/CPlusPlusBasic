#include <iostream>
using namespace std;

int main()
{
	int a, b;
	cin>>a;
	cin >>b;
	float c = a / b; //
	cout << c << endl;
	float d = (float) a / b;
	cout << d << endl;
	system("pause");
	return 0;
}
#include <iostream>
using namespace std;

float Numbers(char c)
{
	float d;
	cout << "Write " << c << "=";
	cin >> d;
	return d;
};

float Equa(float a)
{

	return 2 * (2 * a + 5) / (14 - a / 3);
};

int main()
{

	float y, x;

	y = Numbers('Y');
	cout << "\n";
	x = Equa(y);

	cout << "x = " << x;


	return 0;
}

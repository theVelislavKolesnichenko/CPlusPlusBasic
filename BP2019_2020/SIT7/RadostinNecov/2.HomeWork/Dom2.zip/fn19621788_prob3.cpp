#include <iostream>
using namespace std;

int Numbers(char c)
{
	int d;
	cout << "Write " << c << "=";
	cin >> d;
	return d;
};

float Average(int a, int b, int c, int d)
{

	return float(a + b + c + d) / 4;
};

int main()
{

	int a, b, c, d;

	a = Numbers('A');
	cout << "\n";
	b = Numbers('B');
	cout << "\n";
	c = Numbers('C');
	cout << "\n";
	d = Numbers('D');

	cout << "The average value of the four numbers is " << Average(a, b, c, d);


	return 0;
}

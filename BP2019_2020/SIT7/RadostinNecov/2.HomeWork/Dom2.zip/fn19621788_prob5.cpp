#include <iostream>
using namespace std;

float Numbers(char c)
{
	float d;
	cout << "Write " << c << "=";
	cin >> d;
	return d;
};

float Equa(float a, float b)
{

	return 2 * ((a - b) / (b - a));
};

int main()
{

	float a, b, x;

	a = Numbers('A');
	cout << "\n";
	b = Numbers('B');
	cout << "\n";
	x = Equa(a, b);

	cout << "x = 2((a-b)/(b-a))=" << x;


	return 0;
}

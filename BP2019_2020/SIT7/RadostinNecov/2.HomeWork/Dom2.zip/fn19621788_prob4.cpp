#include <iostream>
using namespace std;

int Number1(int a)
{
	int h = a / 100;
	a = a - 100 * h;
	int t = a / 10;
	a = a - 10 * t;
	return a;
};

int Number10(int a)
{

	int h = a / 100;
	a = a - 100 * h;
	int t = a / 10;

	return t;

};

int Number100(int a)
{

	int h = a / 100;

	return h;
};

int main()
{
	const int a = 837;
	cout << "Hundreds=" << Number100(a) << endl;
	cout << "Tens=" << Number10(a) << endl;
	cout << "Ones=" << Number1(a) << endl;


	return 0;
}

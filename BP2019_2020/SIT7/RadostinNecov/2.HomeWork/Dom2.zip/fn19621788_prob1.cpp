#include <iostream>
using namespace std;

void Start() {
	cout << "Start?";
};
void Finish() {
	cout << "Finish!";
};


int main()
{
	Start();
	int ch = std::cin.get();
	Finish();

	return 0;
}

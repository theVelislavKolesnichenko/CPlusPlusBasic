﻿#include <iostream>
#include <math.h>

using namespace std;



struct Rectangle {

	//Priemam, che stranite na pravougulnika sa ysporedni na koordinatnite osi.

	int x1, y1;
	int x2, y2;

};

int Numbers(string c)
{
	int d;
	cout << "Add " << c << "=";
	cin >> d;
	return d;
};

Rectangle getR() {
	Rectangle r;
	r.x1 = Numbers("x1");
	r.y1 = Numbers("y1");
	r.x2 = Numbers("x2");
	r.y2 = Numbers("y2");

	return r;
};


float Area(Rectangle r) {
	return abs(r.x2 - r.x1) * abs(r.y2 - r.y1);
};

int main()
{
	Rectangle r1 = getR();



	cout << "\n";

	cout << "Area=" << Area(r1) << endl;

	return 0;
}

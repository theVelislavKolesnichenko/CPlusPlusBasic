#include <iostream>
using namespace std;

const float dist = 987.0;

int Numbers(string c)
{
	int d;
	cout << "Add " << c << "=";
	cin >> d;
	return d;
};

float Speed(int a)
{
	return dist / a;
};

float Time(int a)
{
	return dist / a;
};


int main()
{

	int y;

	y = Numbers("time");
	cout << "Speed= " << Speed(y);
	cout << "\n";
	cout << "\n";
	y = Numbers("speed");
	cout << "Time= " << Time(y);

	return 0;
}

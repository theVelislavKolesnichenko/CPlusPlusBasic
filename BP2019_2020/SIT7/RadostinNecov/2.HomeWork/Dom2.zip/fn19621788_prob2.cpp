#include <iostream>
using namespace std;


float Numbers(char c)
{
	float d;
	cout << "Write " << c << "=";
	cin >> d;
	return d;
};

int main()
{
	float a, b;

	a = Numbers('A');
	b = Numbers('B');
	cout << a << "+" << b << "=" << a + b << endl;
	cout << "\n";
	a = Numbers('A');
	b = Numbers('B');
	cout << a << "-" << b << "=" << a - b << endl;;
	cout << "\n";
	a = Numbers('A');
	b = Numbers('B');
	cout << a << "*" << b << "=" << a * b << endl;;
	cout << "\n";
	a = Numbers('A');
	b = Numbers('B');
	cout << a << ":" << b << "=" << a / b << endl;;

	return 0;
}

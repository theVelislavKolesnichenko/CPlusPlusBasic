#include <iostream>
#include <math.h>
using namespace std;

float Numbers(char c)
{
	float d;
	cout << "Write " << c << "=";
	cin >> d;
	return d;
};

float Equa(float a, float b)
{

	return pow((a + b), 3) + (pow(a, 2) + 2 * b * a - 2 * a * b + pow(b, 2));
};

int main()
{

	float a, b, x;

	a = Numbers('A');
	cout << "\n";
	b = Numbers('B');
	cout << "\n";
	x = Equa(a, b);

	cout << "x = " << x;


	return 0;
}

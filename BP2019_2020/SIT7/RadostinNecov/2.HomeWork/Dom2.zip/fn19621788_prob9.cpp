#include <iostream>
#include <math.h>

using namespace std;

struct Triangle {

	int x1, y1;
	int x2, y2;
	int x3, y3;
};

int Numbers(string c)
{
	int d;
	cout << "Add " << c << "=";
	cin >> d;
	return d;
};

Triangle getT() {
	Triangle t;
	t.x1 = Numbers("x1");
	t.y1 = Numbers("y1");
	t.x2 = Numbers("x2");
	t.y2 = Numbers("y2");
	t.x3 = Numbers("x3");
	t.y3 = Numbers("y3");

	return t;

}

float dist(int x, int y, int x1, int y1)
{
	return sqrt(pow((x - x1), 2) + pow((y - y1), 2));
};

float Per(Triangle t) {
	return dist(t.x1, t.y1, t.x2, t.y2) + dist(t.x3, t.y3, t.x2, t.y2) + dist(t.x1, t.y1, t.x3, t.y3);
};

int main()
{
	Triangle t1 = getT();

	cout << "\n";

	cout << "Perimeter=" << Per(t1) << endl;

	return 0;
}

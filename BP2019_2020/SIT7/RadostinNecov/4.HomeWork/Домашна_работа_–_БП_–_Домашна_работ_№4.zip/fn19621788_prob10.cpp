#include <iostream>
#include <cmath>
using namespace std;

int Numbers(char c)
{
    int d;
    cout << "Add " << c << "=";
    cin >> d;
    return d;
};
int Sum(int a){
    int n=1;
    int y;
    int b=0;
    do{
        y=pow(a,n)+1/2*n+1;
        n++;
        b=b+y;
    }
    while(20 >= n);
    return b;
};


int main()
{
    int a;
    a = Numbers('x');

    cout<<"The sums is "<<Sum(a)<<endl;
    return 0;
}

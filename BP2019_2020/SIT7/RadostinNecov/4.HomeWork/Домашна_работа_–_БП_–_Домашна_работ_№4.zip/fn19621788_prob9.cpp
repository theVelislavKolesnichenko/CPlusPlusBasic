#include <iostream>
using namespace std;

int Numbers(char c)
{
    int d;
    cout << "Write a yea" << c << "=";
    cin >> d;
    return d;
};

string god(int a){
    if((a%4==0 && a%100!=0) || a%400==0){
        return " is a leap-year.\n";
    }
    else {
        return " is not a leap-year.\n";
    }
};


int main()
{
    int a;
    do {
        a = Numbers('r');
        cout << a << god(a);
        cout << "\n";
    }
    while(a>0);


    return 0;
}

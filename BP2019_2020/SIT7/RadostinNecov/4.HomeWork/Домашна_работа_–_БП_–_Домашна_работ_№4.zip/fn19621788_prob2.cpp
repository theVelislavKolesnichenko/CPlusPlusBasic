#include <iostream>
using namespace std;

int Numbers(char c)
{
    int d;
    cout << "Mont" << c << "=";
    cin >> d;
    return d;
};
string Mont(int a)
{
    if(a>=3&&a<6)
    {
        return "It's Spring\n";
    }
    else if(a>=6&&a<9){
        return "It's Summer\n";
    }
    else if(a>=9&&a<12){
        return "It's Autumn\n";
    }

    else if(a>12||a<1){
        return "It's not a month on this planet\n";
    }
    else{
        return "It's Winter\n";;
    }
}
int main()
{
    int a;
    a = Numbers('h');
    cout << "\n";

    cout<<Mont(a);

    return 0;
}

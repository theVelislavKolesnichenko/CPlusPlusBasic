#include <iostream>
using namespace std;

int Numbers(char c)
{
    int d;
    cout << "Add a numbe" << c << "=";
    cin >> d;
    return d;
};

string fo(int a){
    if((a>999&&a<=9999)||(a<-999&&a>=-9999)){
        return "Four-digit\n";
    }
    else if(a<=999&&a>=-999&&a!=0){
        return "Less then four-digit\n";
    }
    else if(a>9999||a<-9999){
        return "More then four-digit\n";
    }
    else{
        return 0;
    }
};


int main()
{
    int a;
    do {
        a = Numbers('r');
        cout << fo(a);
        cout << "\n";
    }
    while(a!=0);


    return 0;
}

#include <iostream>
#include <iomanip>

using namespace std;


string first()
{
    int i;
    for(i=7;i>2;i--)
    {
        cout<<setw(i)<<setfill('%')<<" \n";
    }


};

string second(){
    int i;
    for (i=1;i<8; i++)
    {
        if(i<6){
            cout<<setw(i)<<setfill('%')<<" \n";
        }
        else{
            cout<<setw(10-i)<<setfill('%')<<" \n";
        }
    }
};

string third(){
    int i;
    for(i=1;i<=5;i++)
    {
        cout<<setw(i)<<setfill(' ')<<" ";
        cout<<setw(2*(7-i))<<setfill('%')<<" \n";
    }
}


int main()
{

    cout<<first()<<"\n"<<second()<<"\n"<<third();


    return 0;
}


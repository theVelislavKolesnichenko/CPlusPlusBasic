#include <iostream>
#include<math.h>
using namespace std;

float Numbers(char c)
{
    float d;
    cout << "Write " << c << "=";
    cin >> d;
    return d;
};
float roots(float a, float b, float c)
{
    float disc=(b*b)-(4*a*c);
    if(disc<0){
        cout<<"No real roots\n";
    }
    else if(disc==0) {
        cout<<"Only one root - "<<-b/(2*a)<<endl;
    }
    else {
        cout<<"First root is "<<(((-b) + (sqrt(disc)))/(2*a))<<endl;
        cout<<"Second root is "<<(((-b) - (sqrt(disc)))/(2*a))<<endl;
    }
}
int main()
{
    float a, b, d;
    a = Numbers('a');
    cout << "\n";
    b = Numbers('b');
    cout << "\n";
    d = Numbers('d');
    cout << "\n";

    roots(a,2*b, d);

    return 0;
}

#include <iostream>
#include<math.h>
using namespace std;

int Numbers(char c)
{
    int d;
    cout << "Write " << c << "=";
    cin >> d;
    return d;
};
float Ex(int a, int b)
{
    if(a<0)
    {
        cout<<"Invalid Input\n";
    }
    else if(b==0){
        cout<<"Invalid Input\n";
    }
    else{
        return sqrt(a+2)-2/b;
    }
}
int main()
{
    int a, b;
    a = Numbers('a');
    cout << "\n";
    b = Numbers('c');
    cout << "\n";

    cout<<"y="<<Ex(a,b);

    return 0;
}

#include <iostream>
using namespace std;

int p,n;

bool Pos(int a){

    return a>0;
};
bool Neg(int a)
{

    return a<0;
};


int Numbers(char c)
{
    int d;
    cout << "Add a number for " << c << "=";
    cin >> d;
    if (Pos(d))
    {
        p++;
    }
    else if(Neg(d))
    {
        n++;
    }
    return d;
};


int main()
{
    int a1, a2, a3, a4 ,a5 , a6 ,a7, a8, a9, a10;
    a1 = Numbers('a');
    cout << "\n";
    a2 = Numbers('b');
    cout << "\n";
    a3 = Numbers('c');
    cout << "\n";
    a4 = Numbers('d');
    cout << "\n";
    a5 = Numbers('e');
    cout << "\n";
    a6 = Numbers('f');
    cout << "\n";
    a7 = Numbers('g');
    cout << "\n";
    a8 = Numbers('h');
    cout << "\n";
    a9 = Numbers('i');
    cout << "\n";
    a10 = Numbers('j');
    cout << "\n";


    cout<<"The number of positive numbers is "<<p<<endl;
    cout<<"The number of negative numbers is "<<n<<endl;

    return 0;
}

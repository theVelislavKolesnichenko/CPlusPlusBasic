#include <iostream>
#include <algorithm>
using namespace std;

int Numbers(char c)
{
    int d;
    cout << "Add " << c << "=";
    cin >> d;
    return d;
};
int NOK(int a, int b)
{   int maxV;
    maxV = (a > b) ? a : b;
    while(1)
    {

        if((maxV % a == 0) && (maxV % b == 0))
        {
            break;
        }
        ++maxV;
    }
    return maxV;
}
int NOD(int a, int b)
{
    return __gcd(a, b);
}
int main()
{
    int a, b;
    a = Numbers('a');
    cout << "\n";
    b = Numbers('b');
    cout << "\n";

    cout<<"NOK="<<NOK(a, b)<<endl;
    cout<<"NGOD="<<NOD(a, b);
    return 0;
}

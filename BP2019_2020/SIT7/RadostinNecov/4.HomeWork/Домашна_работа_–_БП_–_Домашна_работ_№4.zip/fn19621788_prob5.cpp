#include <iostream>
using namespace std;

int Numbers(char c)
{
    int d;
    cout << "Add " << c << "=";
    cin >> d;
    return d;
};

int Numb(int a){
    int b;
    for (b = 1; b < a - 1; b++)
    {
        cout << b<<" ";
    }

};

int main()
{
    int a;
    a = Numbers('a');
    if(a>0) {
        cout<<Numb(a);
    }
    else{
        cout<<"Not a positive number";
    }
}

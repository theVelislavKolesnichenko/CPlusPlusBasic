#include <iostream>
using namespace std;


int Let(char a)
{
	int x = int(a);

	if ((x > 64) && (x < 91))
	{
		return x - 64;
	}
	else if ((x > 96) && (x < 123))
	{
		return x - 96;
	}
	else
		return 0;

};


int main()
{
	char a;
	cout << "Enter a letter ";
	cin >> a;


	cout << "The number of " << a << " is " << Let(a);


	return 0;
}




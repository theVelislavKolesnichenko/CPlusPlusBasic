#include <iostream>
using namespace std;

double Numbers(char c)
{
	double d;
	cout << "Write " << c << "=";
	cin >> d;
	return d;
};

string PosNeg(double a)
{


	return (a > 0) ? "positive" : ((a < 0) ? "negative" : "zero");
};


int main()
{
	double a;
	a = Numbers('A');
	cout << "\n";

	cout << "The number is " << PosNeg(a);



	return 0;
}




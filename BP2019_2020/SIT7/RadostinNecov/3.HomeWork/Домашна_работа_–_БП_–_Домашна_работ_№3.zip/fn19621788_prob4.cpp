#include <iostream>
using namespace std;

double Numbers(char c)
{
	double d;
	cout << "Write " << c << "=";
	cin >> d;
	return d;
};

double Div(double a)
{
	return double(20 / a);
};


int main()
{
	double a;
	a = Numbers('Y');
	cout << "\n";

	if (a == 0.0)
	{
		cout << "Can't dived by zero\n";
	}
	else {
		cout << "x=20/y, x= " << Div(a);
	}


	return 0;
}





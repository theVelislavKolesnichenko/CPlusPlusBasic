#include <iostream>
using namespace std;

int Numbers(char c)
{
	int d;
	cout << "Write " << c << "=";
	cin >> d;
	return d;
};


int main()
{
	int a, b;
	a = Numbers('A');
	cout << "\n";
	b = Numbers('B');
	cout << "\n";

	cout << "~a=" << ~a << endl;
	cout << "~b=" << ~b << endl;
	cout << "a&&b=" << (a && b) << endl;
	cout << "a||b=" << (a || b) << endl;
	cout << "a^b=" << (a ^ b) << endl;
	cout << "a<<5=" << (a << 5) << endl;
	cout << "b<<5=" << (b << 5) << endl;
	cout << "a>>4=" << (a >> 4) << endl;
	cout << "b>>4=" << (b >> 4) << endl;



	return 0;
}




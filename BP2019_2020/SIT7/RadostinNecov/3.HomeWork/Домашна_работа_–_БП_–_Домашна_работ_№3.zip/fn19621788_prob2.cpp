#include <iostream>
using namespace std;

double Numbers(char c)
{
	double d;
	cout << "Write " << c << "=";
	cin >> d;
	return d;
};

double Bigger(double a, double b)
{

	return ((a > b) ? a : b);

};

int main()
{
	double a, b;
	a = Numbers('A');
	cout << "\n";
	b = Numbers('B');
	cout << "\n";

	cout << "The bigger number is " << Bigger(a, b);



	return 0;
}




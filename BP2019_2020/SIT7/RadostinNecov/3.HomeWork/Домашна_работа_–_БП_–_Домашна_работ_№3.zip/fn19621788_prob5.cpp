#include <iostream>
#include <math.h>
using namespace std;


double Numbers(char c)
{
	double d;
	cout << "Write " << c << "=";
	cin >> d;
	return d;
};

double LTO(double a)
{
	if (a < 1) {

		return pow(a, 3) + (a * 4 + 2 * a);

	}
	else if (a > 1) {

		return 2 * (2 * a + 5) / (14 - a / 3);

	}
	else {

		cout << "Y is equal to 1\n";
		return 0;

	}
};


int main()
{
	double a;
	a = Numbers('Y');
	cout << "\n";

	cout << "x= " << LTO(a);



	return 0;
}




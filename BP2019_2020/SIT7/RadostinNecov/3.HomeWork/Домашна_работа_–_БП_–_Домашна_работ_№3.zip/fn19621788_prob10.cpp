#include <iostream>
#include <math.h>
using namespace std;


int Numbers(char c)
{
	int d;
	cout << "Write " << c << "=";
	cin >> d;
	return d;
};

string EvOd(int a)
{
	if (a % 2 == 0) {

		return "even";

	}
	else {

		return "odd";

	}
};


int main()
{
	int a;
	a = Numbers('A');
	cout << "\n";

	cout << a << " is " << EvOd(a);



	return 0;
}


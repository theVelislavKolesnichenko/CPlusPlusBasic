#include <iostream>
#include <math.h>
using namespace std;


int Numbers(char c)
{
	int d;
	cout << "Write " << c << "ears=";
	cin >> d;
	return d;
};

string Year(int a)
{
	if ((a >= 0) && (a < 1)) {

		return "a baby";
	}
	else if ((a >= 1) && (a < 3)) {

		return "a toddler";
	}
	else if ((a >= 3) && (a < 5)) {

		return "a preschooler";
	}
	else if ((a >= 5) && (a <= 12)) {

		return "a gradeschooler";
	}
	else if ((a >= 13) && (a < 18)) {

		return "a teen";
	}
	else if ((a >= 18) && (a < 21)) {

		return "a young adult";
	}
	else if (a < 0) {
		return "not born yet";
	}
	else {
		return "too old for this";
	}
};


int main()
{
	int a;
	a = Numbers('y');
	cout << "\n";

	cout << "Your kid is " << Year(a);



	return 0;
}




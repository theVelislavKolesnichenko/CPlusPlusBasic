﻿#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	float a;
	float h;

	cout << "Add the base of the triangle a=";
	cin >> a;
	cout << "Add the height of the triangle h=";
	cin >> h;

	
	cout << "The area of the triangle is S=" << (a*h)/2 << endl;

	return 0;

}


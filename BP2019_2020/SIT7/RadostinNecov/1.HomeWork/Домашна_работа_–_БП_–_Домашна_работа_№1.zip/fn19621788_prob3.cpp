#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	int a = 576;
	int h = a / 100;
	a = a - 100 * h;
	int t = a / 10;
	a = a - 10 * t;


	cout << "Units "<< a <<" Tens "<< t <<" Hundreds " << h << endl;




	return 0;
}
#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	int a;
	int b;
	int c;

	cout << "Add a=";
	cin >> a;
	cout << "Add b=";
	cin >> b;
	cout << "Add c=";
	cin >> c;

	cout << "The average value of a, b and c is " << (a + b + c) / 3 << endl;
	
	return 0;

}

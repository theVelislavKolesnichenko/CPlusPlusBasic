﻿#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	float a;
	float x;
	float c;

	cout << "Add a=";
	cin >> a;
	cout << "Add c=";
	cin >> c;

	x = (2 * a + 5) / (14 - c / 3);
	cout << "With x = (2a + 5)/(14 - c/3), x=" << x << endl;

	return 0;

}

//"Съставете програма която да изчисли x = (2y + 5)/(14 - y/3) при въведени от клавиатурата стойности за a и c. Тъй като в уравнението има Y, а то не е сред дадените стойности за въвеждане замених първото с A, второто с C "
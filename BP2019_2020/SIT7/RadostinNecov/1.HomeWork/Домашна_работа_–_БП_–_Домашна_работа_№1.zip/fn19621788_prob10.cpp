#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	float a;
	float h;

	cout << "Add the width of the rectangle a=";
	cin >> a;
	cout << "Add the height of the rectangle h=";
	cin >> h;


	cout << "The area of the rectangle is S=" << (a * h) << endl;
	cout << "The perimeter of the rectangle is P=" << (a+h)*2 << endl;

	return 0;

}


#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	int a;
	int b;
	int c;

	cout << "Add a=";
	cin >> a;
	cout << "Add b=";
	cin >> b;
	cout << "Add c=";
	cin >> c;

	cout << "With x=2(a-b)(a-c), x=" << 2 * (a - b) * (a - c) << endl;

	return 0;

}
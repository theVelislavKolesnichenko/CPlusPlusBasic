#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	std::cout.width(6);
	cout << std::left << "Rank";
	std::cout.width(19);
	cout << "Gymnast";
	std::cout.width(10);
	cout << "Nation";
	std::cout.width(8);
	cout << "Ribbon";
	std::cout.width(8);
	cout << "Ball";
	std::cout.width(8);
	cout << "Batons";
	std::cout.width(8);
	cout << "Hoop";
	std::cout.width(8);
	cout << "Total" << endl;

	std::cout.width(6);
	cout << std::left << "1";
	std::cout.width(19);
	cout << "Dina Averina";
	std::cout.width(10);
	cout << "Russia";
	std::cout.width(8);
	cout << "21.650";
	std::cout.width(8);
	cout << "22.950";
	std::cout.width(8);
	cout << "23.000";
	std::cout.width(8);
	cout << "23.800";
	std::cout.width(8);
	cout << "91.400" << endl;

	std::cout.width(6);
	cout << std::left << "2";
	std::cout.width(19);
	cout << "Arina Averina";
	std::cout.width(10);
	cout << "Russia";
	std::cout.width(8);
	cout << "20.850";
	std::cout.width(8);
	cout << "23.100";
	std::cout.width(8);
	cout << "24.050";
	std::cout.width(8);
	cout << "23.100";
	std::cout.width(8);
	cout << "91.100" << endl;

	std::cout.width(6);
	cout << std::left << "3";
	std::cout.width(19);
	cout << "Linoy Ashram";
	std::cout.width(10);
	cout << "Israel";
	std::cout.width(8);
	cout << "21.050";
	std::cout.width(8);
	cout << "23.100";
	std::cout.width(8);
	cout << "23.500";
	std::cout.width(8);
	cout << "22.050";
	std::cout.width(8);
	cout << "89.700" << endl;

	std::cout.width(6);
	cout << std::left << "4";
	std::cout.width(19);
	cout << "Boryana Kaleyn";
	std::cout.width(10);
	cout << "Bulgaria";
	std::cout.width(8);
	cout << "19.900";
	std::cout.width(8);
	cout << "22.400";
	std::cout.width(8);
	cout << "22.350";
	std::cout.width(8);
	cout << "21.625";
	std::cout.width(8);
	cout << "86.275" << endl;

	std::cout.width(6);
	cout << std::left << "5";
	std::cout.width(19);
	cout << "Vlada Nikolchenko";
	std::cout.width(10);
	cout << "Ukraine";
	std::cout.width(8);
	cout << "19.450";
	std::cout.width(8);
	cout << "22.250";
	std::cout.width(8);
	cout << "19.500";
	std::cout.width(8);
	cout << "22.950";
	std::cout.width(8);
	cout << "84.150" << endl;

	


	

	return 0;
}

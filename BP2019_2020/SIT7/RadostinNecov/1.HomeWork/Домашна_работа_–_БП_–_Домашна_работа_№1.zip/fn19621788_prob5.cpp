#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	std::cout.width(4);
	cout << std::left << "a)";
	std::cout.width(8);
	cout << "%%%%%";
	std::cout.width(4);
	cout << "b)";
	std::cout.width(8);
	cout << "%";
	std::cout.width(4);
	cout << "c)";
	std::cout.width(8);
	cout << "%";
	std::cout.width(4);
	cout << "d)";
	std::cout.width(10);
	cout << "%%%%%%%%%%" << endl;

	std::cout.width(4);
	cout << std::left << " ";
	std::cout.width(8);
	cout << "%%%%";
	std::cout.width(4);
	cout << " ";
	std::cout.width(8);
	cout << "%%";
	std::cout.width(4);
	cout << " ";
	std::cout.width(8);
	cout << "%%";
	std::cout.width(4);
	cout << " ";
	std::cout.width(10);
	cout << " %%%%%%%% " << endl;

	std::cout.width(4);
	cout << std::left << " ";
	std::cout.width(8);
	cout << "%%%";
	std::cout.width(4);
	cout << " ";
	std::cout.width(8);
	cout << "%%%";
	std::cout.width(4);
	cout << " ";
	std::cout.width(8);
	cout << "%%%";
	std::cout.width(4);
	cout << " ";
	std::cout.width(10);
	cout << "  %%%%%%  " << endl;

	std::cout.width(4);
	cout << std::left << " ";
	std::cout.width(8);
	cout << "%%";
	std::cout.width(4);
	cout << " ";
	std::cout.width(8);
	cout << "%%";
	std::cout.width(4);
	cout << " ";
	std::cout.width(8);
	cout << "%%%%";
	std::cout.width(4);
	cout << " ";
	std::cout.width(10);
	cout << "   %%%%   " << endl;

	std::cout.width(4);
	cout << std::left << " ";
	std::cout.width(8);
	cout << "%";
	std::cout.width(4);
	cout << " ";
	std::cout.width(8);
	cout << "%";
	std::cout.width(4);
	cout << " ";
	std::cout.width(8);
	cout << "%%%%%";
	std::cout.width(4);
	cout << " ";
	std::cout.width(10);
	cout << "    %%    " << endl;


	return 0;
}


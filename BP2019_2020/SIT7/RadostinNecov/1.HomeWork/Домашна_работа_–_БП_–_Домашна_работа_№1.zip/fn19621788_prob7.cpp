﻿#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	int a;
	int c;

	cout << "Add a=";
	cin >> a;
	cout << "Add c=";
	cin >> c;

	char sq=251;
	cout << "With y=" << sq << "(a+2)-c2, y=" << sqrt(a + 2) - c * 2 << endl;

	return 0;

}
﻿#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	int a;
	int b;
	float c;
	float d;

	cout << "Add a=";
	cin >> a;
	cout << "Add b=";
	cin >> b;

	c = a / b;
	cout << "C=" << c << endl;

	d = float(a) / b;
	cout << "D="<< d << endl;


	return 0;


}
// При С изчислението е между две цели числа и за това по подразбиране връща целочислен резултат.
// При D изчислението е между цяло число и число с плаваща запетая, поради което връща резултат с плаваща запетая.
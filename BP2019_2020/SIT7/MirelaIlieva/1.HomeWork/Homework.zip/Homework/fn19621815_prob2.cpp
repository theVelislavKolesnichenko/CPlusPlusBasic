﻿#include <iostream>
using namespace std;
int main()
{
	int a;
	int b;
	int c;

	cout << "a:";
	cin >> a;
	cout << "b:";
	cin >> b;
	cout << "c:";
	cin >> c;
	cout << "Srednata stoinost e:" << (a + b + c) / 3;
	
	return 0;
	
}


﻿#include <iostream>
using namespace std;
int main()
{
	int a;
	int b;
	int c;
	int z;

	cout << "a:";
	cin >> a;
	cout << "b:";
	cin >> b;
	cout << "c:";
	cin >> c;
	z = 2 * (a - b) * (a - c);
	cout << z;
	return 0;
}


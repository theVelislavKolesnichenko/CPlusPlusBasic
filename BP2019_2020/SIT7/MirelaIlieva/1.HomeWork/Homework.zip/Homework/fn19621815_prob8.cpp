﻿#include <iostream>
using namespace std;
int main()
{
	double x;
	int y;

	cout << "y:";
	cin >> y;
	x = ((2*y) + 5) / (14 - (double)y / 3);
	cout << x;
	return 0;

}


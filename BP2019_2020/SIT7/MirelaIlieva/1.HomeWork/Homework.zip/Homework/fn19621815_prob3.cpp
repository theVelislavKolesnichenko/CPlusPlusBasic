﻿#include <iostream>
using namespace std;

int main() {
	int number = 576;
	int u = number % 10;
	int t = (number / 10)%10;
	int h = (number / 100)%10;

	cout << " Units "<< u; 
	cout << " Tens " << t;
	cout << " Hundreds " << h;
	
	return 0;
}
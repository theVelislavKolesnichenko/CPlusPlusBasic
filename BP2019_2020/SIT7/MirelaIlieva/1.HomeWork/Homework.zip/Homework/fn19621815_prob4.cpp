﻿#include <iostream>
#include <iomanip>
using namespace std;

int main()
{

	cout << "Rank" << setw(10) <<
	"Gymnast"<< setw(15) <<
	"Nation" << setw(15) <<
	"Ribbon" << setw(15) <<
	"Ball" << setw(16) <<
	"Batons" << setw(13) <<
	"Hoop" << setw(16) <<
	"Total" << endl;

	cout << "1" << setw(18) << 
	"Dina Averina" << setw(10) << 
	"Russia" << setw(15) <<
	"21.650" << setw(17) << 
	"22.950" << setw(14) <<
	"23.000" << setw(15) <<
	"23.800" << setw(15) <<
	"91.400" << endl;

	cout << "2" << setw(19) <<
	"Arina Averina" << setw(9) <<
	"Russia" << setw(15) <<
	"20.850" << setw(17) <<
	"23.100" << setw(14) <<
	"24.050" << setw(15) <<
	"23.100" << setw(15) <<
	"91.100" << endl;

	cout << "3" << setw(18) <<
	"Linoy Ashram" << setw(10) <<
	"Israel" << setw(15) <<
	"21.050" << setw(17) <<
	"23.100" << setw(14) <<
	"23.500" << setw(15) <<
	"22.050" << setw(15) <<
	"89.700" << endl;

	cout << "4" << setw(20) <<
		"Boryana Kaleyn" << setw(10) <<
		"Bulgaria" << setw(13) <<
		"19.900" << setw(17) <<
		"22.400" << setw(14) <<
		"22.350" << setw(15) <<
		"21.625" << setw(15) <<
		"86.275" << endl;
		
	cout << "5" << setw(20) <<
		"Vlada Nikolchenko" << setw(10) <<
		"Ukraine " << setw(13) <<
		"19.450" << setw(17) <<
		"22.250" << setw(14) <<
		"19.500" << setw(15) <<
		"22.950" << setw(15) <<
		"84.150" << endl;

	return 0;
}
﻿#include <iostream>
using namespace std;
int main()
{
	int a = 10;
	int b = 3;
	double c;
	float d;

	d = ((float)a / b);
	c = ((double)a / b);
	cout << "c=" << c << endl;
	cout << "d=" << d;

	return 0;
}



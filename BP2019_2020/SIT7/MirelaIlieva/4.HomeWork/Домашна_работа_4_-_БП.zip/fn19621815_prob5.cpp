﻿#include <iostream>
using namespace std;

void numbers();

int main()
{
	numbers();
}
	
void numbers()
{

	int n;
	cin >> n;

	for (int i = 1; i <= n; i++)
	{
		cout << i << " ";
	}

}
﻿#include <iostream>
using namespace std;

int NOD();
int NOK();

int main()
{
	cout <<" NOD " << NOD() << endl;
	cout <<" NOK " << NOK();
}

int NOD()
{
	int a;
	int b;
	int i;
	cout << " a= ";
	cin >> a;
	cout << " b= ";
	cin >> b;
	for (int i = (a, b); i >= 1; i--)
	{
		if (a % i == 0 && b % i == 0)
		{
			return i;
		}
	}
}

int NOK()
{
	int a;
	int b;
	int i;
	cout << " a= ";
	cin >> a;
	cout << " b= ";
	cin >> b;
	for (int i = (a, b); i <= (a * b); i++)
	{
		if (i % a == 0 && i % b == 0)
		{
			return i;
		}
	}

}

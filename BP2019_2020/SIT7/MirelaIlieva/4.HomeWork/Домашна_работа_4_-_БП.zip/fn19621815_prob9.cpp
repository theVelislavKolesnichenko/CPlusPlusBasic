﻿#include <iostream>
using namespace std;

void year();

int main()
{
	year();
}

void year()
{
	int year;
	cout << "Enter a year:" << endl;
	cin >> year;
	if ((year % 4 == 0) && (year % 100 != 0))
	cout << "The year is a leap" << endl;
	else
	cout << "The year is not a leap" << endl; 
}


﻿#include <iostream>
using namespace std;

double sum(double a, double b);
double substraction(double a, double b);
double multiplication(double a, double b);
double division(double a, double b);

int main()
{
	double a = 3;
	double b = 2;
	double x = 5.5;
	double y = 9;
	double z = 7.8;
	double t = 5;
	double h = 8.1;
	double m = 2;
	double c;
	c = sum(a, b);
	cout << c << endl;
	c = substraction(x, y);
	cout << c << endl;
	c = division(z, t);
	cout << c << endl;
	c = multiplication(h, m);
	cout << c << endl; 

}

double sum(double a, double b)
{
	double result;
	result = a + b;
	cout << a << " + " << b << " = ";
	return result;
}

double substraction(double a, double b)
{
	double result;
	result = a - b;
	cout << a << " - " << b << " = ";
	return result;
}

double multiplication(double a, double b)
{
	double result; 
	result = a * b;
	cout << a << " * " << b << " = ";
	return result;
}
double division(double a, double b)
{
	double result; 
	result = a / b;
	cout << a << " / " << b << " = ";
	return result;
}






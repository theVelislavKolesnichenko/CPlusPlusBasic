﻿#include <iostream>
#include <stdio.h>
using namespace std;

void printStart() {
	cout << "Start" << endl;
}
void printFinal() {
	cout << "Final" << endl;
}

int main()
{	
	char c;
	printStart();
	c = getchar();
	printFinal();

}



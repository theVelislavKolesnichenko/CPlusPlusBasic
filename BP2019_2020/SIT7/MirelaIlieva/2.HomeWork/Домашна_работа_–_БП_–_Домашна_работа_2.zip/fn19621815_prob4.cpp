﻿#include <iostream>
using namespace std;

int units(int);
int tens(int);
int hundreds(int);

int main()
{
	int number = 837;
	int u;
	int t;
	int h;

	cout << " Units: " << u;
	units(u);
	cout << " Tens: " << t;
	tens(t);
	cout << " Hundreds: " << h;
	hundreds(h);
}

int units(int u)
{
	int result;
	int number = 837;
	u = number % 10;
	return result;
}

int tens(int t)
{
	int result;
	int number = 837;
	t = (number / 10) % 10;
	return result;
}

int hundreds(int h)
{
	int result;
	int number = 837;
	h = (number / 100) % 10;
	return result;
}


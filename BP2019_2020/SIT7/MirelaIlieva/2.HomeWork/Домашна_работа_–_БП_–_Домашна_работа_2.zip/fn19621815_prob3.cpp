#include <iostream>
using namespace std;

double averageNumber(double a, double b, double c, double d)
{	
	double result;
	result = a + b + c + d / 4;
	return result;
}
		
int main()
{
	double a;
	double b; 
	double c;
	double d;
	cin >> a >> b >> c >> d;
	double result = averageNumber(a, b, c, d);
	cout << result;
	return 0;
	
}
  






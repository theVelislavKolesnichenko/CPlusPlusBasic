﻿#include <iostream>
using namespace std;


int main()
{
	int years;
	cout << " Enter years ";
	cin >> years;

	if (years == 0 || years == 1)
	{
		cout << " Baby ";
	}
	if (years == 2 || years == 3)
	{
		cout << " Toddler ";
	}
	if (years == 4 || years == 5)
	{
		cout << " Preschool ";
	}
	if (years >= 6 && years <= 12)
	{
		cout << " Gradeschooler";
	}
	if (years >= 13 && years <= 17)
	{
		cout << " Teen ";
	}
	if (years >= 18 && years <= 21)
	{
		cout << " Young adult ";
	}
}


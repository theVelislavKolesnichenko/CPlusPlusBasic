﻿#include <iostream>
using namespace std;

int equation1(int);
int equation2(int);

int main()
{
	int y;
	cout << " y= ";
	cin >> y;
	if (y >= 58 && y <= 87)
	{
		cout << " x= " << equation1(y) << endl;
	}
	else {}
	if (y > 15 && y < 58)
	{
		cout << " x= " << equation2(y) << endl;
	}
	else {}

	return 0;
}

int equation1(int y)
{
	return pow(y, 3) + (pow(y, 4) + (2 * y));
}

int equation2(int y)
{
	return 2 * (2 * y + 5) / (14 - y / 3);
}



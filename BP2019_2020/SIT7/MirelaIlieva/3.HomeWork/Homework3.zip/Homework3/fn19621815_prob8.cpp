﻿#include <iostream>
using namespace std;

int main()
{
	int symbol;
	cin >> symbol;

	switch (symbol)
	{
	case 1:
		cout << "A";
		break;
	case 2:
		cout << "B";
		break;
	case 3:
		cout << "C";
		break;
	case 4:
		cout << "D";
		break;
	case 5:
		cout << "E";
		break;
	case 6:
		cout << "F";
		break;
	}
}



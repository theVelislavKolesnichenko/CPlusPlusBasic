﻿#include <iostream>
using namespace std;

int main()
{
	int number;
	int n;
	cin >> number;
	cout << EvenOrOdd(n);

}
 
int EvenOrOdd(int)
{	
	int number;
	if (number % 2 == 0)
	{
		cout << " This number is even. " << endl;
	}
	else
	{
		cout << " This number is odd. " << endl;
	}
	
}

﻿#include <iostream>
using namespace std;

int equation1(int y);
int equation2(int y);

int main()
{
	int y;
	cout << " y =  ";
	cin >> y;
	if (y < 1)
	{
		cout << "result = " << equation1(y) << endl;
	}
	else {}
	if (y > 1)
	{
		cout << "result = " << equation2(y) << endl;
	}
	else {}
	return 0;
}

int equation1(int y)
{
	return pow(y, 3) + (pow(y, 4) + (2 * y));
}

int equation2(int y)
{
	return 2 * (2 * y + 5) / (14 - y / 3);
}
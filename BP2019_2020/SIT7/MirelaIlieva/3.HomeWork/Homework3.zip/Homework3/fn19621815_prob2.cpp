﻿#include <iostream>
using namespace std;

double max(double a, double b);

int main()
{
	double a;
	double b;
	cin >> a >> b;
	cout << max(a, b);
}
double max(double a, double b)
{
	if (a > b)
	{
		return a;
	}
	else
	{
		return b;
	}
}
﻿#include <iostream>
using namespace std;

double equation(double y);

int main()
{
	double y;
	cout << " y= ";
	cin >> y;
	if (y != 0)
	{
		cout << " x = " << equation(y) << endl;
	}
	else
	{ 
		cout << "It is not divisible by 0";
	}
}

double equation(double y)
{
		return 20 / y;
}
		
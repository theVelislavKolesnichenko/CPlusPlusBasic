﻿#include <iostream>
using namespace std;

int main()
{
	double a;
	cin >> a;
	string  result = PositiveOrNegative(a);
	cout << result;
}
string PositiveOrNegative(double a)
{
	if (a >= 0)
	{
		string result;
		result = "Positive";
		return result;
	}
	else
	{
		string result;
		result = "Negative";
		return result;
	}
}

#include<iostream>
using namespace std;
int start;
int final;

int main()
{
	cout << "Start ?" << endl;
	getchar();

	cout << "Final !";
}


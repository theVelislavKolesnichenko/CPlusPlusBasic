#include <iostream>

using namespace std;

float enterNumber (float var);
float calcAverage (float a, float b, float c, float d);

int main() {
    float m,n, p, q, var;

    m = enterNumber(var);
    n = enterNumber(var);
    p = enterNumber(var);
    q = enterNumber(var);

    calcAverage(m,n,p,q);

    return 0;
}

float enterNumber (float var) {
    cout << "Enter a number... \n";
    cin >> var;

    cout << "The number you have entered is " << var << endl;

    return var;
}

float calcAverage (float m, float n, float p, float q) {
    cout << "The average of the four numbers is " << (m + n + p + q) / 4;
    return (m + n + p +q) / 4;
}
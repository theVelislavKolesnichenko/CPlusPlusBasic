#include <iostream>
#include <iomanip>
using namespace std;

int main()
{

	cout << "Rank" << setw(11) << "Gymnast" << setw(16) << "Nation" << setw(16) << "Ribbon" << setw(16) << "Ball" << setw(17) << "Batons" << setw(14) << "Hoop" << setw(17) <<
		"Total" << endl;

	cout << "1" << setw(19) << "Dina Averina" << setw(11) << "Russia" << setw(16) << "21.650" << setw(18) << "22.950" << setw(15) << "23.000" << setw(16) << "23.800" << setw(16) <<
		"91.400" << endl;

	cout << "2" << setw(20) << "Arina Averina" << setw(10) << "Russia" << setw(16) << "20.850" << setw(18) << "23.100" << setw(15) << "24.050" << setw(16) << "23.100" << setw(16) <<
		"91.100" << endl;

	cout << "3" << setw(19) << "Linoy Ashram" << setw(11) << "Israel" << setw(16) << "21.050" << setw(18) << "23.100" << setw(15) << "23.500" << setw(16) << "22.050" << setw(16) <<
		"89.700" << endl;

	cout << "4" << setw(21) << "Boryana Kaleyn" << setw(11) << "Bulgaria" << setw(14) << "19.900" << setw(18) << "22.400" << setw(15) << "22.350" << setw(16) << "21.625" << setw(16) <<
		"86.275" << endl;

	cout << "5" << setw(21) << "Vlada Nikolchenko" << setw(11) << "Ukraine " << setw(14) << "19.450" << setw(18) << "22.250" << setw(15) << "19.500" << setw(16) << "22.950" << setw(16) <<
		"84.150" << endl;

	return 0;
}
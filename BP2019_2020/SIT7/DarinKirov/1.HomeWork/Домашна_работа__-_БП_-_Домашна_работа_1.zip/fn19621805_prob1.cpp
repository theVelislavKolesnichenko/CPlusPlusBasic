#include <iostream>
#include <math.h>
using namespace std;


int main()

{
	float a = 6.2;
	int b = 2;
		int c = a / b; 
		float d = a / b;
		


		cout << "c=a/b=" << c << endl; // 3   Sus int vuvejdame samo cqlata chast na rezultata, a s 
		cout << "d=a/b=" << d << endl; // 3.1       float i drobnata chast, koqto e sled zapetaikata.
	






	return 0;

}
#include <iostream>
using namespace std;


int main()


{
	int num = 576;
		int u, t, h;

		u = num % 10;
		t = (num / 10) % 10;
		h = (num / 100) % 10;

		cout << "Units" << u << "Tens" << t << "Hundreds" << h << endl;








	return 0;
}
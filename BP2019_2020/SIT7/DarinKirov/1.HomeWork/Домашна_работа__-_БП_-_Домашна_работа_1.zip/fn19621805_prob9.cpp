#include <iostream>
#include <math.h>

using namespace std;


int main()

{
	double a;
	double ha;
	double s;

	cout << "Vuvedete stranata na triugulnika a=" << endl;
	cin >> a;
	cout << "Vuvedete visochinata kum stranata a na triugulnika ha=" << endl;
	cin >> ha;
	cout << "Liceto na triugulnika S=" << (a * ha) / 2;










	return 0;
}
#include <iostream>
#include <math.h>
using namespace std;


int main()
{
	double a;
	double b;

	cout << "Vuvedete ednata strana na pravougulnika a=" << endl;
	cin >> a;
	cout << "Vuvedete vtorata strana na pravougulnika b=" << endl;
	cin >> b;


	cout << "Obikolkata na pravougulnika P=" << 2 * (a + b) << endl;
	cout << "Liceto na pravougulnika S=" << a * b << endl;










	return 0;
}
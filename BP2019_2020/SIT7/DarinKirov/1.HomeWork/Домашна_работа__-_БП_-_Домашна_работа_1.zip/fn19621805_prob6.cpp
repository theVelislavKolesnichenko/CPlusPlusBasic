#include <iostream>
#include <iomanip>
#include <math.h>
using namespace std;


int main()

{
	int a;
	int b;
	int c;
	int z;
		cout << "Vuvedete a=" << endl;
	cin >> a;
	cout << "Vuvedete b=" << endl;
	cin >> b;
	cout << "Vuvedete c=" << endl;
	cin >> c;

	cout << "z=2*(a - b) * (a -c) =" << 2*(a-b)*(a-c)  << endl;


	return 0;


}
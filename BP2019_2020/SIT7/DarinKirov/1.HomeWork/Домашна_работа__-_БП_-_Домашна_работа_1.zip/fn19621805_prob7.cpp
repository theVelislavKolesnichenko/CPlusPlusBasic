#include <iostream>
#include <math.h>
using namespace std;


int main()
{
	double a;
	double c;
	double y;


	cout << "Vuvedete a=" << endl;
	cin >> a;
	cout << "Vuvedete c=" << endl;
	cin >> c;

	cout << "y=sqrt(a+2) - pow(c,2)=" << sqrt(a + 2) - pow(c, 2) << endl;






	return 0;
}
#include <iostream>
#include <math.h>
using namespace std;


int main()


{
	int a, b, c;
	cout << "Vuvedete a=" << endl;
	cin >> a;
	cout << "Vuvedete b=" << endl;
	cin >> b;
	cout << "Vuvedete c=" << endl;
	cin >> c;

	cout << "Srednata stoinost na a, b, c =" << (a + b + c) / 3 << endl;







	return 0;
}
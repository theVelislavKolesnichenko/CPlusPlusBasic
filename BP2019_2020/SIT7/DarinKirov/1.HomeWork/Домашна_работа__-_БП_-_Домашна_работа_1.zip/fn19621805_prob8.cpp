#include <iostream>
#include <math.h>
using namespace std;



int main()

{
	double x;
	double y;

	cout << "Vuvedete stoinostta na y=" << endl;
	cin >> y;
	cout << "x=(2*y+5)/(14-y/3)=" << (2 * y + 5) / (14 - y/3) << endl;










	return 0;
}
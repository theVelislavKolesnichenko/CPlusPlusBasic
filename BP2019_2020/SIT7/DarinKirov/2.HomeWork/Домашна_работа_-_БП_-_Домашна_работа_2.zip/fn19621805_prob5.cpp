#include <iostream>
using namespace std;

double input();
double calc(double a, double b);

double input()
{
	double number;
	cin >> number;
	return number;
}

double calc(double a, double b)
{
	double result;
	result = 2 * ((a - b) / (b - a));
	return result;
}

int main()
{
	double a, b;
	cout << "Enter a: ";
	a = input();
	cout << "Enter b: ";
	b = input();
	cout << "Result: " << calc(a, b) << endl;

	return 0;
}
#include <iostream>
using namespace std;

void start();
void final();

int main()
{
	start();
	final();
	return 0;
}

void start()
{
	cout << "Start ?" << endl;
	system("pause");
}

void final()
{
	cout << "Final !" << endl;
}

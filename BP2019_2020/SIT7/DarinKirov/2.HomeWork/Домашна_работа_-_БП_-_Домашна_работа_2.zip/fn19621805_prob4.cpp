#include <iostream>
using namespace std;

int ones(int number);
int tens(int number);
int hundreds(int number);

int main()
{
	const int number = 837;
	ones(number);
	tens(number);
	hundreds(number);
	int a, b, c;
	a = ones(number);
	b = tens(number);
	c = hundreds(number);

	cout << "837: " << endl;
	cout << "Ones: " << a << endl;
	cout << "Tens: " << b << endl;
	cout << "Hundreds: " << c << endl;
	return 0;
}

int ones(int number)
{
	int ones;
	ones = number % 10;
	return ones;
}

int tens(int number)
{
	int tens;
	tens = (number / 10) % 10;
	return tens;
}

int hundreds(int number)
{
	int hundreds;
	hundreds = number / 100;
	return hundreds;
}
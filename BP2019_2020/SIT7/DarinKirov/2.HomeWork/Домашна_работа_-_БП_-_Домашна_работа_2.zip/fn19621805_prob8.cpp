#include <iostream>
using namespace std;

double speed(double hours);
double time(double kms);

const int length = 987;
int main()
{
	int hours, kms;
	cout << "Travel time: "; cin >> hours;
	cout << "Required speed: " << speed(hours) << " km/h." << endl;
	cout << "Current speed: "; cin >> kms;
	cout << "Remaining time: " << time(kms) << " hours." << endl;
	return 0;
}

double speed(double hours)
{
	double result;
	result = length / hours;
	return result;
}

double time(double kms)
{
	double result;
	result = length / kms;
	return result;

}
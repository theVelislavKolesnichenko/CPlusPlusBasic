#include <iostream>
using namespace std;


struct triangle
{
	double a, b, c;
}triangle1;

double P();


triangle input()
{
	triangle triangle1;
	cout << "Enter a: "; cin >> triangle1.a;
	cout << "Enter b: "; cin >> triangle1.b;
	cout << "Enter c: "; cin >> triangle1.c;
	return triangle1;
}


double P(triangle triangle1)
{
	double result;
	result = triangle1.a + triangle1.b + triangle1.c;
	return result;
}


int main()
{
	triangle triangle1;
	triangle1 = input();
	cout << "P: " << P(triangle1) << endl;

}

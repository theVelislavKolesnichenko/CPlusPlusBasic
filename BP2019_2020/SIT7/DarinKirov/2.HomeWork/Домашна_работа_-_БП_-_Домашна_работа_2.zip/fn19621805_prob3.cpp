#include <iostream>
using namespace std;

double input();
double average(double a, double b, double c, double d);

double input()
{
	double number_a;
	cin >> number_a;
	return number_a;
}

double average(double a, double b, double c, double d)
{
	double result;
	result = (a + b + c + d) / 4;
	return result;
}


int main()
{
	double a, b, c, d;

	cout << "Enter a: ";
	a = input();
	cout << "Enter b: ";
	b = input();
	cout << "Enter c: ";
	c = input();
	cout << "Enter d: ";
	d = input();
	cout << "Average: " << average(a, b, c, d) << endl;

	return 0;
}


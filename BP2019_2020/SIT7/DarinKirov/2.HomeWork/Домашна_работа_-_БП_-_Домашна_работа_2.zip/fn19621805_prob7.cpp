#include <iostream>
using namespace std;

double input();
double calc(double y);

double input()
{
	double number;
	cin >> number;
	return number;
}

double calc(double y)
{
	double result;
	result = 2 * ((2 * y + 5) / (14 - y / 3));
	return result;
}

int main()
{
	double y;
	cout << "Enter y: ";
	y = input();
	cout << "Result: " << calc(y) << endl;

	return 0;
}
#include <iostream>
using namespace std;

double input();
double Subirane(double a, double b);
double Izvajdane(double a, double b);
double Umnojenie(double a, double b);
double Delenie(double a, double b);

double input()
{
	double number;
	cout << "Enter number: "; cin >> number;
	return number;
}

double Subirane(double a, double b)
{
	double result;
	result = a + b;
	return result;
}

double Izvajdane(double a, double b)
{
	double result;
	result = a - b;
	return result;
}

double Umnojenie(double a, double b)
{
	double result;
	result = a * b;
	return result;
}

double Delenie(double a, double b)
{
	double result;
	result = a / b;
	return result;
}

int main()
{
	double a, b;
	a = input();
	b = input();
	cout << "Subirane: " << endl << a << " + " << b << " = " << Subirane(a, b) << endl << endl;
	a = input();
	b = input();
	cout << "Izvajdane: " << endl << a << " - " << b << " = " << Izvajdane(a, b) << endl << endl;
	a = input();
	b = input();
	cout << "Umnojenie: " << endl << a << " * " << b << " = " << Umnojenie(a, b) << endl << endl;
	a = input();
	b = input();
	cout << "Delenie: " << endl << a << " / " << b << " = " << Delenie(a, b) << endl << endl;
	return 0;
}
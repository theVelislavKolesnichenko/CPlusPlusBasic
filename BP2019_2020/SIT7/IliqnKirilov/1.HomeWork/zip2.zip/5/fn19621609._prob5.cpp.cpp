#include <iostream>
using namespace std;

int main ()
{
	int a,b,x ;
	int result ;
	result = x = 2 * ((a-b) / (b-a)) ;
	cout << "Enter a number: "<< endl;
	cin >> a ;
	cout << "Enter a second number: " << endl;
	cin >> b ;
	cout <<"The result is: "<< result ;
	return 0 ;
}

#include <iostream>
using namespace std;

int main ()
{
int distance , speed , time ;
distance = 987 ;
cout << "Enter time in km/h " << endl;
cin >> time ;
cout << "Time is: " << time << " km/h "<< endl;
speed = distance / time ;
cout << distance<< " km " << "and the speed to travel through is  " << speed << " hours" << endl;
return 0 ;
}


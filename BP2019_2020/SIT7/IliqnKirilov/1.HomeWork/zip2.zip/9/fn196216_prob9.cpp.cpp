#include <iostream>
using namespace std;

	struct structure {
		int a,b,c ;
	}p1,p2,p3;
		
		int main ()
		{
		int P ;
	structure a,b,c ;
	p1.a = 10 ;
	p2.b = 12 ;
	p3.c= 17 ;
    P = p1.a + p2.b + p3.c ;
    cout << "The round of the triangle is: " << P << endl;
    return 0 ;

}

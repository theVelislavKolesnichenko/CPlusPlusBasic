#include <iostream>
using namespace std;
  

int main()
{
	float a,b,c,d,e ;
	cout << "Enter a number: " << endl;
	cin >> a ;
	cout << "Enter a second number: " << endl;
	cin >> b ;
	int result1,result2,result3,result4 ;
	result1 = a + b ;
	cout << a <<  " plus " << b << " equals: " << result1 << endl << endl ;
	cout << "Enter a third number: " << endl;
	cin >> c ;
	result2 = result1 - c ;
	cout << result1 << " minus the " << c << " equals to: " << result2 << endl << endl;
	cout << "Enter a forth number: " << endl;
	cin >> d ;
	result3 = result2 / d ;
	cout << result2 << " divided by " << d << " equals to: " << result3 << endl;
	cout << "Enter a fifth number: " << endl << endl ;
	cin >> e ;
	result4 = result3 * e ;
	cout << result3 << " multiplied by " << e << " equals to: " << result4 << endl;
	return 0 ;
	

}
 

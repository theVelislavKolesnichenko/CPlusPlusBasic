#include <iostream>
using namespace std;

	struct structure {
		int a,b;
	}p1,p2;
		
		int main ()
		{
		
	structure a,b ;
	int S;
	p1.a = 13 ;
	p2.b = 11 ;
    S= p1.a * p2.b;
    cout << "The face of a rectangle: " << S << endl;
    return 0 ;

}

#include <iostream>
using namespace std;

int main ()
{
	int a,b,x ;
	int result ;
	result = x = (a+b)^3 + (a^2+2*b*a -2*a*b+b^2)  ;
	cout << "Enter a number: "<< endl;
	cin >> a ;
	cout << "Enter a second number: " << endl;
	cin >> b ;
	cout <<"The result is: "<< result ;
	return 0 ;
}

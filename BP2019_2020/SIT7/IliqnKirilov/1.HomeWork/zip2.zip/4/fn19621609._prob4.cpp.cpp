#include <iomanip>
 #include <iostream>
 using namespace std;
  int main ()
   {
   	
   	int a ;
   	cout << "Enter a number: \n" ;
	 scanf("%i",&a);
	 short s,d,e; s=a/100; d=a/10%10; e=a%10;
	  cout << setw(10) << "hundreds: " << setw(5) << s << "\n"; cout << setw(10) << "dozens:" << setw(5) << d << "\n"; cout << setw(10) << "units: " << setw(5) << e << "\n";
 } 

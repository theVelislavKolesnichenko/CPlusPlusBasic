#include <iostream>
using namespace std;

int main ()
{
	float a,b,c,d ;
	cout << "Enter a number: " << endl;
	cin >> a ;
	cout << "Enter a second number: " <<endl;
	cin >> b ;
	cout << "Enter a third number: " <<endl;
	cin >> c ;
	cout << "Enter a fourth number: " << endl;
	cin >> d ;
	int result ;
	result = (a - b) - (c - d);
	cout <<"The average value is: "<< result ;
	return 0;
}

#include <iostream>
using namespace std;
  

void printmessage(int & z)
{
	cout << "Final!" ;
}

int main ()
{
    int a ;
	cout << "Start? \n" ;
	cin >> a ;
	printmessage(a) ;
	return 0 ;
}


  	

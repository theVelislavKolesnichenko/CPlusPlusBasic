#include <iostream>
using namespace std;

int main ()
{
	int y,x ;
	x = 2 * (2*y+5) / (14 - y / 3) ;
	cout << "Enter a number: "<< endl;
	cin >> y ;
	cout <<"The result is: "<< x << endl ;
	return 0 ;
}

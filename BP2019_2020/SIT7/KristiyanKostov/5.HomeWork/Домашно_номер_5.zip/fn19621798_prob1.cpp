#include <iostream>
using namespace std;
int Proizvedenie (int,int);
int main ()
{
	int a,sum=1;
	do{
	cout<<"a=";
	cin>>a;
	if (a>0)
	{ sum=Proizvedenie(a,sum);
	}
	} while(a>0);
	cout<<sum<<endl;
	system ("pause");
	return 0;
}

int Proizvedenie (int a,int b)
{
	int c=a*b;
	return c;
}
	

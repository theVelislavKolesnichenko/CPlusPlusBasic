#include <iostream>
using namespace std;
void sum (int a,int b, int *sum);
int main()
{
	int a,b,*mul;
	cout<<"a=";
	cin>>a;
	do{
	cout<<"b=";
	cin>>b;
	} while (a>b);
	cout<<*mul;
	sum(*mul);
	cout<<*mul;
	system ("pause");
	return 0;
}

void sum (int a,int b, int *sum)
{ 
	(*sum)=a+b;
}

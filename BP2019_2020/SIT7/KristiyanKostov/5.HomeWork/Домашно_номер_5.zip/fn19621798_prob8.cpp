#include <iostream>
using namespace std;
void func (int *p);
int main()
{
	int a;
	func(&a);
	cout<<a;
	system ("pause");
	return 0;
}

void func (double*p)
{ double a;
cin>>a;
(*p)=a;
}


#include <iostream>
using namespace std;
int chisla(int x);
int main()
{
	int a;
	cout<<"a=";
	cin>>a;
	cout<<chisla(a)<<endl;
	system ("pause");
	return 0;
}
int chisla (int x)
{
	int a=1;
	while (x=x/10);
	{ 
		a++;
		x=x/10;
	}
	
	return a;
}

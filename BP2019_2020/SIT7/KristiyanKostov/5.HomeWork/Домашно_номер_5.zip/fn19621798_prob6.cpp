#include <iostream>
#include <math.h>
using namespace std;
double Sum3 (double,double,double);
int main ()
{
	double a,b,c;
do{
	
		cout<<"a=";
		cin>>a;
		cout<<"b=";
		cin>>b;
		cout<<"c=";
		cin>>c;
	
		
	}while (a!=0 && b!=0 && c!=0);
	cout<<Sum3<<endl;
	system ("pause");
	return 0;
}
double Sum3 (double a ,double b,double c)
{ 
	int sum;
	return sum=a+b+c;
	
}
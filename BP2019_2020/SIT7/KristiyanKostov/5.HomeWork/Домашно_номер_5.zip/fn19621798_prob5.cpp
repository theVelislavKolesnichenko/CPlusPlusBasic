#include <iostream>
#include <math.h>
using namespace std;
int AVG ();
int main ()
{
	cout<<AVG()<<endl;
	system ("pause");
	return 0;

}
int AVG ()


{ 
	int a,sum=0;
	for(int i=0;i<10;i++)
	{
		cout<<"a=";
		cin>>a;
		sum=sum+a;
	}
	return sum/10;

}
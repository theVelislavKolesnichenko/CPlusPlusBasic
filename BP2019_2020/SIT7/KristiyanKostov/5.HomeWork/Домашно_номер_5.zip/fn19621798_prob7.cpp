#include <iostream>
using namespace std;
bool prosti (int);
int main ()
{
	for (int i=1;i<20;i++)
	{
		if (prosti(i))
		{ cout<<i<<endl;
		}
		
	system ("pause");
	return 0;
	}
}
	bool prosti (int a)
	{
		for (int i=2;i<a;i++)
		{
			if(a%i==0)
		return false;
			}
		
	return true;
	}


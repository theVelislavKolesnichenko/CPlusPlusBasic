#include <iostream>
#include <math.h>
using namespace std;
double uravnenie(int x);
int main ()
{
	int a;
	do{
		cout<<"a=";
		cin>>a;
		break;
	}while (a>-100 || a<100);
	cout<<uravnenie(a)<<endl;
	system ("pause");
	return 0;
}
double uravnenie (int x)
{ 

	if (x<0)
	{ 
		return sqrt((pow(x,2)+1));
	}
	else if (x>=0)
	{
		return ((x+10))/((x-20));
	}
}
#include <iostream>
using namespace std;
void mul (int a,int b, int *mul);
int main()
{
	int a,b,mul;
	cout<<"a=";
	cin>>a;
	do{
	cout<<"b=";
	cin>>b;
	} while (a>b);
	cout<<mul;
	mul(a,b,&mul);
	cout<<mul;
	system ("pause");
	return 0;
}

void mul (int a,int b, int *mul)
{ 
	(*mul)=a*b;
}

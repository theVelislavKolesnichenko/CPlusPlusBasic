#include <iostream>
#include <math.h>
using namespace std;
 
struct Triangle 
{
    int a,b,c;
};
 
Triangle getData(Triangle);
int Peremeter(Triangle);
 
int main()
{
    Triangle t;
    t = getData(t);  
    cout<<"P= "<<Peremeter(t)<<endl;
    system("pause");
    return 0;
}
 
Triangle getData(Triangle t)
{
    cout << "a= ";
    cin>>t.a;
    cout << "b= ";
    cin>>t.b;  
    cout << "c= ";
    cin>>t.c;
    return t;
}
 
int Peremeter(Triangle t)
{
  int P=t.a+t.b+t.c;
  return P;
}
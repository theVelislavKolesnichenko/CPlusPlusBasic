#include <iostream>
using namespace std;
 
int edinici(int);
int desetici(int);
int stotici(int);
 
int main() {
    int a=837;
    cout<<"edinici "<<edinici(a)<<endl;
    cout<<"desetici "<<desetici(a)<<endl;
    cout<<"stotici "<<stotici(a)<<endl;
   
    system ("pause");
    return 0;
}
int edinici(int a){
    return (a%100)%10;
}
 
int desetici(int a){
    return (a/10)%10;
}
 
int stotici(int a){
    return a/100;
}
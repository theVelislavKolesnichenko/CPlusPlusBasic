#include <iostream>
#include <conio.h>
using namespace std;
 
void Start ();
void Final ();
 
int main()
{
    Start ();
    getch();
    Final();
    system("pause");
    return 0;
}
void Start ()
{
    cout<<"Start?"<<endl;
}
 
void Final ()
{
    cout<<"Final !"<<endl;
}
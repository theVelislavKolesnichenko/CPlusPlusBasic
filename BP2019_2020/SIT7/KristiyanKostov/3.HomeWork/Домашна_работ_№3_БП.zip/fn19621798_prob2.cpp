#include <iostream>
#include <math.h>
using namespace std;
double sum(double , double );
double sss(double , double );
double ddd(double , double );
double aaa(double , double );
double Vuvejdane(double);
 
 
int main()
{
    double a,b;        
    a=Vuvejdane(a);
    cout<<"a="<<a<<endl;
    b=Vuvejdane(b);
    cout<<"b="<<b<<endl;
    cout<<sum(a,b)<< endl;  
    cout<<sss(a,b)<<endl;
    cout<<ddd(a,b)<<endl;
    cout<<aaa(a,b)<<endl;
    system("pause");
    return 0;
}
 
double sum(double a, double b)
{
    double result;
    result = a + b;
    return result;
}
 
double sss(double a, double b)
{
    double result;
    result = a - b;
    return result;
}
 
double ddd(double a, double b)
{
    double result;
    result = a/b;
    return result;
}
 
double aaa(double a, double b)
{
    double result;
    result = a*b;
    return result;
}
 
double Vuvejdane(double a){                  
    cout<<"vuvedi: ";
    cin>>a;
    return a;
}
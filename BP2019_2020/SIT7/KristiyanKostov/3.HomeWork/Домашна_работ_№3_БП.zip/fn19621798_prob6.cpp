#include <iostream>
#include <math.h>
using namespace std;
 
double Calc(double,double);
double Vuvejdane(double);
 
int main() 
{
   double a=0,b=0;
   a=Vuvejdane(a);
   b=Vuvejdane(b);
   cout<<"Result= "<<Calc(a,b)<<endl;
   
    system ("pause");
    return 0;
}
double Calc(double a, double b)
{                  
    double x;
    x = pow((a+b),3) + (pow(a,2)+(2*b*a)-(2*b*a)+pow(b,2)); 
    return x;
}
 
double Vuvejdane(double a)
{                  
    cout<<"vuvedi: ";
    cin>>a;
    return a;
}
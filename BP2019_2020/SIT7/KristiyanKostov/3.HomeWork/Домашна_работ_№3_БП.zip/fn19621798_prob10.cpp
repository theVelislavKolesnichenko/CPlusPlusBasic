#include <iostream>
#include <math.h>
using namespace std;
 
struct Pravougulnik 
{
    int a,b;
};
 
Pravougulnik getData(Pravougulnik);
int Lice (Pravougulnik);
 
int main()
{
    Pravougulnik p;
    p = getData(p);  
    cout<<"S= "<<Lice(p)<<endl;
    system("pause");
    return 0;
}
 
Pravougulnik getData(Pravougulnik p) {
    cout << "a= ";
    cin>>p.a;
    cout << "b= ";
    cin>>p.b;  
    return p;
}
 
int Lice(Pravougulnik p)
{
  int S=(p.a)*(p.b);
  return S;
}
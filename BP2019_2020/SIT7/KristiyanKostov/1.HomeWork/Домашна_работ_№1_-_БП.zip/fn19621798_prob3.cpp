#include <iostream>
using namespace std;
int main()
{
	int a=576;
	int b= a/100;
	int c= a%10;
	int d= (a%100)/10;
	cout<<"Units " << c << " Tens "<<d<<" Hundreds "<<b<<endl;
	
	system ("pause");
		return 0;
}
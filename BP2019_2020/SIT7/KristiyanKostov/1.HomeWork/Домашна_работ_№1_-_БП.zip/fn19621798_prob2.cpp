#include <iostream>
using namespace std;
int main()
{
	int a,b,c;
	float d;
	cout<<"a=";
	cin>>a;
	cout<<"b=";
	cin>>b;
	cout<<"c=";
	cin>>c;
	d=(float(a)+float(b)+float(c))/3;
	cout<<d<<endl;
	
	
	system ("pause");
		return 0;
}
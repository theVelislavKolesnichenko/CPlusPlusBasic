#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	float a,ha,S;
	cout<<"a=";
	cin>>a;
	cout<<"ha=";
	cin>>ha;
	S=(a*ha)/2;
	cout<<S<<endl;
	
	
	system ("pause");
		return 0;
}
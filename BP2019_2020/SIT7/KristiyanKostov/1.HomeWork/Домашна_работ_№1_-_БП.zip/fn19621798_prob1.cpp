#include <iostream>
using namespace std;
int main()
{
	int a,b;
	cout<<"Vuvedi a=";

	cin>>a;
	cout<<"Vuvedi b=";
	cin>>b;
	float c;
	c= float (a) / float (b);
	cout<<c<<endl;
	a = float(a);
	float d;
	d= a / float (b);
	cout<<d<<endl;
	cout<<"Pri uslovie a) dokato se izchislqva c, a i b se konventirat na float"<<endl;
	cout<<"Pri uslovie b) dokato se izchislqva d, konventirame samo b na float, zashtoto a veche e konventiranov vuv float"<<endl;

	system ("pause");
		return 0;
}
#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	int a,b,P,S;
	cout<<"a=";
	cin>>a;
	cout<<"b=";
	cin>>b;
	P=(2*a) + (2*b);
	cout<<"P="<<P<<endl;
	S=a*b;
	cout<<"S="<<S<<endl;
	
	
	system ("pause");
		return 0;
}
#include <iostream>
#include <math.h>
using namespace std;
 
double v(int,double);
double t(int,double);
 
int main() 
{
   int S=987;
   double vreme;
   cout<<"vreme ";
   cin>>vreme;
   cout<<"skorost(v)=: "<<v(S,vreme)<<endl;
   double skorost;
   cout<<"skorost ";
   cin>>skorost;
   cout<<"vreme(t)=: "<<t(S,skorost)<<endl;
   
    system ("pause");
    return 0;
}
double v(int S, double vreme)
{                  
    double v;
    v=double(S)/vreme;
    return v;
}
 
double t(int S, double skorost)
{                  
    double t;
    t=double(S)/skorost;
    return t;
}
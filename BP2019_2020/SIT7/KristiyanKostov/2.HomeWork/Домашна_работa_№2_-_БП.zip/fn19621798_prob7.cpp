#include <iostream>
#include <math.h>
using namespace std;
 
double Calc(double);
double Vuvejdane(double);
 
int main() 
{
   double y=0;
   y=Vuvejdane(y);
   cout<<"Result="<<Calc(y)<<endl;
   
    system ("pause");
    return 0;
}
double Calc(double y)
{                  
    double x;
    x = 2*((2*y)+5)/(14-(y/3));

    return x;
}
 
double Vuvejdane(double y)
{                  
    cout<<"vuvedi: ";
    cin>>y;
    return y;
}

#include <iostream>
#include <math.h>
using namespace std;
double AVG(double,double,double,double);
double Vuvejdane(double);
 
 
int main()
{
    double a=0,b=0,c=0,d=0;          
    a=Vuvejdane(a);
    b=Vuvejdane(b);
    c=Vuvejdane(c);
    d=Vuvejdane(d);
    cout<<AVG(a,b,c,d)<<endl;
    system("pause");
    return 0;
}
double AVG(double a, double b, double c, double d)
{
    double result;
    result = (a+b+c+d)/4;
    return result;
 
}
 
double Vuvejdane(double a){                  
    cout<<"vuvedi: ";
    cin>>a;
    return a;
}
#include <iostream>
#include <iomanip>
using namespace std;
int hi();
int bye();
int hibye ();
int main ()
{ 


	cout<<"A --->"<<endl;
	cout<<endl;
	cout<<bye()<<endl;
	cout<<endl;
	cout<<endl;
	cout<<endl;
	cout<<endl;
	cout<<"B --->"<<endl;
	cout<<endl;
	cout<<hi()<<endl;
	cout<<endl;
	cout<<endl;
	cout<<endl;
	cout<<endl;
	cout<<"C --->"<<endl;
	cout<<endl;
	cout<<hibye()<<endl;

	system ("pause");
	return 0;


}

int hi()
{
	char x='%';
	int i=0;
	while (i<1)
	{
	cout<<x<<endl;
 cout<<x<<x<<endl;
cout<<x<<x<<x<<endl;
cout<<x<<x<<endl;
cout<<x<<endl;
i= i+1;
	}
return 0;
}
int bye()
{
	char x='%';
for (int i=0;i<5;i++)
cout<<x;
cout<<endl;
for (int i=0;i<4;i++)
cout<<x;
cout<<endl;
for (int i=0;i<3;i++)
cout<<x;
cout<<endl;
for (int i=0;i<2;i++)
cout<<x;
cout<<endl;
for (int i=0;i<1;i++)
cout<<x;
cout<<endl;
return 0;
}

int hibye ()
{
	int i=0;
	char x='%';
	do
	{ 
	cout<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<endl;
	cout<<x<<x<<x<<x<<x<<x<<x<<x<<endl;	
    cout<<x<<x<<x<<x<<x<<x<<endl;
	cout<<x<<x<<x<<x<<endl;
	cout<<x<<x<<endl;
		i++;
	}
	while (i<1);
	return 0;
}
		

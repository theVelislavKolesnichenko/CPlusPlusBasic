#include <iostream>
#include <math.h>
using namespace std;

double func(double,double,double);

int main()
{
	double x,y,z,a,b,d;
cout<<"a=";
cin>>x;
cout<<"b=";
cin>>y;
cout<<"d=";
cin>>z;
cout<<"Korenut e"<<func(x,y,z)<<endl;
system("pause");
return 0;
}
double func(double a,double b,double d)
{
	int x;
	return pow(a,x)+2*b*x+d;
}
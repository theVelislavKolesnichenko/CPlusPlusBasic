#include <iostream>
using namespace std;

void reshenie (double,double);
int main()
{
	double a,c;
	cout<<"a=";
	cin>>a;
	cout<<"c=";
	cin>>c;
	reshenie (a,c);
	system ("pause");
	return 0;
}

void reshenie (double a,double c)
{ 
	if (a>0 && c!=0)
	{
		cout<<(sqrt(a+2)) - 2/c<<endl;
	}
	else if (a<0 || c==0)
	{
		cout<<"Invalid input"<<endl;
	}
}
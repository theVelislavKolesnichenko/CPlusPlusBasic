#include <iostream>
using namespace std;
int NOD(int,int);
int NOK(int, int);

int main ()
{
	int a,b,x,y;
	cout<<"x=";
	cin>>x;
	cout<<"y=";
	cin>>y;
cout<<"NOD e:"<<NOD(x,y)<<endl;
cout<<"NOK e:"<<NOK(x,y)<<endl;
system ("pause");
return 0;
}
int NOD(int a,int b)
{
	for (int i=min(a,b); i>=1; i--)
	{ 
		if (a%i==0 && b%1==0);
	return i;
	}
}
int NOK(int a,int b)
{
	for (int i=max(a,b); i<=(int)a*b; i++)
	{ 
		if (i%a==0 && i%b==0)
	return i;
	}
}
#include <iostream>
using namespace std;
int chislo (int );

int main()
{
	int a;
	cout<<"a=";
	cin>>a;
	chislo(a);
	system ("pause");
	return 0;
}

int chislo (int a)
{
	for (int i=1; i<a; i++)
	{
		cout<<i<<endl;
	}
	return a;
}

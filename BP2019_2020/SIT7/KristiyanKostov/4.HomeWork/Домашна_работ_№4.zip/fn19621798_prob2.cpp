#include <iostream> 
using namespace std; 
void Sezon(int);

int main() 
{ 
    int a; 
	cout<<"a=";
	cin>>a; 
    Sezon(a); 


	system ("pause");
    return 0; 
} 

void Sezon(int a)
{

    switch (a)  
    { 
        case 12: 
        case 1: 
        case 2: 
            cout << "Zima"<<endl;
            break; 
        case 3: 
        case 4: 
        case 5: 
            cout << "Prolet"<<endl; 
            break; 
        case 6: 
        case 7: 
        case 8: 
            cout << "Lqto"<<endl; 
            break; 
        case 9: 
        case 10: 
        case 11: 
			cout << "Esen"<<endl; 
            break; 
        default: 
         
            cout <<"Nqma takuv sezon"<<endl; 
            break; 
    } 
} 